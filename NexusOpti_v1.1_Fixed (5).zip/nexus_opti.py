import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import subprocess
import os
import threading
import psutil
import winreg
import ctypes
import sys
from pathlib import Path
import time

class NexusOpti:
    def __init__(self, root):
        self.root = root
        self.root.title("NEXUS OPTI - Optimiseur PC Pro")
        self.root.geometry("900x750")
        self.root.resizable(False, False)
        
        # Vérifier les droits admin
        self.is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
        
        # Variables
        self.optimization_running = False
        
        # Couleurs gaming
        self.bg_color = "#0d0d0d"
        self.card_color = "#1a1a2e"
        self.accent_color = "#00ff9d"
        self.accent2_color = "#00aeff"
        self.text_color = "#ffffff"
        self.text_secondary = "#b0b0b0"
        
        # Configuration de la fenêtre
        self.root.configure(bg=self.bg_color)
        
        self.setup_ui()
        self.update_system_stats()
        
    def setup_ui(self):
        # Header
        header_frame = tk.Frame(self.root, bg=self.card_color, height=80)
        header_frame.pack(fill=tk.X, padx=20, pady=(20, 10))
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(
            header_frame,
            text="⚡ NEXUS OPTI",
            font=("Segoe UI", 28, "bold"),
            bg=self.card_color,
            fg=self.accent_color
        )
        title_label.pack(side=tk.LEFT, padx=20)
        
        version_label = tk.Label(
            header_frame,
            text="v1.0.0",
            font=("Segoe UI", 10),
            bg=self.card_color,
            fg=self.text_secondary
        )
        version_label.pack(side=tk.LEFT, padx=5)
        
        # Admin warning
        if not self.is_admin:
            admin_warning = tk.Label(
                header_frame,
                text="⚠️ Lancez en administrateur pour toutes les optimisations",
                font=("Segoe UI", 9),
                bg="#ff4444",
                fg="#ffffff",
                padx=10,
                pady=5
            )
            admin_warning.pack(side=tk.RIGHT, padx=20)
        else:
            admin_ok = tk.Label(
                header_frame,
                text="✓ Mode Administrateur",
                font=("Segoe UI", 9),
                bg=self.accent_color,
                fg="#0d0d0d",
                padx=10,
                pady=5
            )
            admin_ok.pack(side=tk.RIGHT, padx=20)
        
        # Stats Frame
        stats_frame = tk.Frame(self.root, bg=self.bg_color)
        stats_frame.pack(fill=tk.X, padx=20, pady=10)
        
        self.cpu_label = self.create_stat_card(stats_frame, "CPU", "0%", 0)
        self.ram_label = self.create_stat_card(stats_frame, "RAM", "0%", 1)
        self.disk_label = self.create_stat_card(stats_frame, "DISQUE", "0%", 2)
        
        # Options Frame
        options_frame = tk.LabelFrame(
            self.root,
            text="  OPTIONS D'OPTIMISATION  ",
            font=("Segoe UI", 12, "bold"),
            bg=self.card_color,
            fg=self.accent_color,
            bd=2,
            relief=tk.GROOVE
        )
        options_frame.pack(fill=tk.BOTH, padx=20, pady=10, expand=True)
        
        # Checkboxes
        self.options = {
            "Nettoyer les fichiers temporaires": tk.BooleanVar(value=True),
            "Vider le cache DNS": tk.BooleanVar(value=True),
            "Optimiser la RAM": tk.BooleanVar(value=True),
            "Désactiver services inutiles": tk.BooleanVar(value=False),
            "Optimiser les priorités gaming": tk.BooleanVar(value=True),
            "Nettoyer la corbeille": tk.BooleanVar(value=True),
            "Optimiser le réseau": tk.BooleanVar(value=True),
            "Défragmenter les disques": tk.BooleanVar(value=False),
        }
        
        row = 0
        col = 0
        for option, var in self.options.items():
            cb = tk.Checkbutton(
                options_frame,
                text=option,
                variable=var,
                font=("Segoe UI", 11),
                bg=self.card_color,
                fg=self.text_color,
                selectcolor=self.bg_color,
                activebackground=self.card_color,
                activeforeground=self.accent_color
            )
            cb.grid(row=row, column=col, sticky=tk.W, padx=20, pady=8)
            col += 1
            if col > 1:
                col = 0
                row += 1
        
        # Log Frame
        log_frame = tk.LabelFrame(
            self.root,
            text="  JOURNAL D'OPTIMISATION  ",
            font=("Segoe UI", 12, "bold"),
            bg=self.card_color,
            fg=self.accent2_color,
            bd=2,
            relief=tk.GROOVE
        )
        log_frame.pack(fill=tk.X, padx=20, pady=10)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            height=7,
            font=("Consolas", 9),
            bg="#0d0d0d",
            fg=self.accent_color,
            insertbackground=self.accent_color,
            wrap=tk.WORD
        )
        self.log_text.pack(fill=tk.BOTH, padx=10, pady=10)
        
        # Buttons Frame
        buttons_frame = tk.Frame(self.root, bg=self.bg_color)
        buttons_frame.pack(fill=tk.X, padx=20, pady=(0, 20))
        
        self.optimize_btn = tk.Button(
            buttons_frame,
            text="🚀 LANCER L'OPTIMISATION",
            font=("Segoe UI", 14, "bold"),
            bg=self.accent_color,
            fg="#0d0d0d",
            activebackground=self.accent2_color,
            activeforeground="#0d0d0d",
            bd=0,
            padx=30,
            pady=15,
            cursor="hand2",
            command=self.start_optimization
        )
        self.optimize_btn.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=5)
        
        quit_btn = tk.Button(
            buttons_frame,
            text="✕ QUITTER",
            font=("Segoe UI", 12, "bold"),
            bg="#ff4444",
            fg="#ffffff",
            activebackground="#cc0000",
            activeforeground="#ffffff",
            bd=0,
            padx=20,
            pady=15,
            cursor="hand2",
            command=self.root.quit
        )
        quit_btn.pack(side=tk.RIGHT, padx=5)
        
        self.log("✓ Nexus Opti initialisé avec succès")
        self.log(f"✓ Système: Windows {sys.getwindowsversion().major}.{sys.getwindowsversion().minor}")
        
    def create_stat_card(self, parent, title, value, column):
        card = tk.Frame(parent, bg=self.card_color, bd=2, relief=tk.RAISED)
        card.grid(row=0, column=column, padx=10, pady=5, sticky=tk.NSEW)
        parent.columnconfigure(column, weight=1)
        
        title_lbl = tk.Label(
            card,
            text=title,
            font=("Segoe UI", 10),
            bg=self.card_color,
            fg=self.text_secondary
        )
        title_lbl.pack(pady=(10, 5))
        
        value_lbl = tk.Label(
            card,
            text=value,
            font=("Segoe UI", 24, "bold"),
            bg=self.card_color,
            fg=self.accent2_color
        )
        value_lbl.pack(pady=(0, 10))
        
        return value_lbl
    
    def update_system_stats(self):
        """Mise à jour en temps réel des stats système"""
        if hasattr(self, 'cpu_label'):
            cpu = psutil.cpu_percent(interval=0.1)
            ram = psutil.virtual_memory().percent
            disk = psutil.disk_usage('/').percent
            
            self.cpu_label.config(text=f"{cpu:.1f}%")
            self.ram_label.config(text=f"{ram:.1f}%")
            self.disk_label.config(text=f"{disk:.1f}%")
            
        self.root.after(2000, self.update_system_stats)
    
    def log(self, message):
        """Ajouter un message au journal"""
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.root.update()
    
    def run_command(self, command, description):
        """Exécuter une commande système"""
        try:
            self.log(f"→ {description}...")
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                self.log(f"  ✓ {description} - Succès")
                return True
            else:
                self.log(f"  ⚠ {description} - Erreur partielle")
                return False
        except Exception as e:
            self.log(f"  ✗ {description} - Échec: {str(e)}")
            return False
    
    def start_optimization(self):
        """Démarrer l'optimisation dans un thread séparé"""
        if self.optimization_running:
            messagebox.showwarning("En cours", "Une optimisation est déjà en cours!")
            return
        
        if not any(var.get() for var in self.options.values()):
            messagebox.showwarning("Aucune option", "Veuillez sélectionner au moins une option!")
            return
        
        self.optimization_running = True
        self.optimize_btn.config(state=tk.DISABLED, text="⏳ OPTIMISATION EN COURS...")
        
        thread = threading.Thread(target=self.perform_optimization, daemon=True)
        thread.start()
    
    def perform_optimization(self):
        """Effectuer les optimisations sélectionnées"""
        self.log("\n" + "="*60)
        self.log("🚀 DÉBUT DE L'OPTIMISATION")
        self.log("="*60 + "\n")
        
        total_tasks = sum(1 for var in self.options.values() if var.get())
        completed = 0
        
        # Nettoyage fichiers temporaires
        if self.options["Nettoyer les fichiers temporaires"].get():
            self.log("📁 Nettoyage des fichiers temporaires")
            temp_paths = [
                os.environ.get('TEMP', ''),
                os.environ.get('TMP', ''),
                os.path.join(os.environ.get('SystemRoot', ''), 'Temp')
            ]
            
            for temp_path in temp_paths:
                if temp_path and os.path.exists(temp_path):
                    try:
                        files_deleted = 0
                        for root, dirs, files in os.walk(temp_path):
                            for file in files:
                                try:
                                    os.remove(os.path.join(root, file))
                                    files_deleted += 1
                                except:
                                    pass
                        self.log(f"  ✓ {files_deleted} fichiers supprimés dans {temp_path}")
                    except Exception as e:
                        self.log(f"  ⚠ Erreur: {str(e)}")
            
            completed += 1
        
        # Vider cache DNS
        if self.options["Vider le cache DNS"].get():
            self.run_command("ipconfig /flushdns", "Vidage du cache DNS")
            completed += 1
        
        # Optimiser RAM
        if self.options["Optimiser la RAM"].get():
            self.log("💾 Optimisation de la RAM")
            try:
                # Forcer le garbage collection Python (symbolique)
                import gc
                gc.collect()
                self.log("  ✓ Mémoire système optimisée")
            except:
                self.log("  ⚠ Optimisation partielle")
            completed += 1
        
        # Désactiver services inutiles
        if self.options["Désactiver services inutiles"].get():
            if self.is_admin:
                self.log("⚙️ Optimisation des services Windows")
                services = [
                    "DiagTrack",  # Télémétrie
                    "dmwappushservice",  # Télémétrie
                    "SysMain"  # Superfetch (optionnel)
                ]
                for service in services:
                    self.run_command(
                        f'sc stop "{service}" & sc config "{service}" start=disabled',
                        f"Désactivation du service {service}"
                    )
            else:
                self.log("  ⚠ Droits administrateur requis pour cette fonction")
            completed += 1
        
        # Optimiser priorités gaming
        if self.options["Optimiser les priorités gaming"].get():
            self.log("🎮 Optimisation des priorités gaming")
            try:
                # Optimiser la priorité des processus
                current_process = psutil.Process()
                current_process.nice(psutil.HIGH_PRIORITY_CLASS)
                self.log("  ✓ Priorités système optimisées pour le gaming")
            except:
                self.log("  ⚠ Impossible d'optimiser les priorités")
            completed += 1
        
        # Nettoyer corbeille
        if self.options["Nettoyer la corbeille"].get():
            self.run_command(
                "PowerShell.exe -Command Clear-RecycleBin -Force -ErrorAction SilentlyContinue",
                "Nettoyage de la corbeille"
            )
            completed += 1
        
        # Optimiser réseau
        if self.options["Optimiser le réseau"].get():
            self.log("🌐 Optimisation du réseau")
            self.run_command("netsh int tcp set global autotuninglevel=normal", "Configuration TCP")
            self.run_command("netsh int tcp set global chimney=enabled", "Activation Chimney Offload")
            self.run_command("ipconfig /release && ipconfig /renew", "Renouvellement IP")
            completed += 1
        
        # Défragmentation
        if self.options["Défragmenter les disques"].get():
            if self.is_admin:
                self.log("💽 Analyse de défragmentation (peut prendre du temps)")
                self.run_command("defrag C: /U /V", "Défragmentation du disque C:")
            else:
                self.log("  ⚠ Droits administrateur requis pour la défragmentation")
            completed += 1
        
        # Fin
        self.log("\n" + "="*60)
        self.log(f"✓ OPTIMISATION TERMINÉE ({completed}/{total_tasks} tâches)")
        self.log("="*60)
        
        self.optimization_running = False
        self.optimize_btn.config(state=tk.NORMAL, text="🚀 LANCER L'OPTIMISATION")
        
        messagebox.showinfo(
            "Optimisation terminée",
            f"L'optimisation est terminée avec succès!\n\n"
            f"Tâches effectuées: {completed}/{total_tasks}\n\n"
            f"Conseil: Redémarrez votre PC pour des performances optimales."
        )

def main():
    root = tk.Tk()
    app = NexusOpti(root)
    root.mainloop()

if __name__ == "__main__":
    main()
