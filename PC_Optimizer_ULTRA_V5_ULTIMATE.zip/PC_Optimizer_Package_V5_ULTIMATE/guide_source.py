"""
PC OPTIMIZER - GUIDE D'INSTALLATION
Application standalone qui explique les étapes d'installation
"""

import tkinter as tk
from tkinter import messagebox, ttk
import os

class InstallGuide:
    def __init__(self, root):
        self.root = root
        self.root.title("PC Optimizer - Guide d'Installation & Utilisation")
        self.root.geometry("900x750")
        self.root.resizable(True, True)
        self.root.minsize(800, 650)
        
        # Couleurs modernes
        self.bg = "#0f172a"
        self.card = "#1e293b"
        self.accent = "#3b82f6"
        self.text = "#f1f5f9"
        self.text2 = "#94a3b8"
        self.success = "#10b981"
        self.warning = "#f59e0b"
        
        self.root.configure(bg=self.bg)
        self.setup_ui()
        
    def create_logo(self, parent):
        """Créer le logo PC Optimizer"""
        c = tk.Canvas(parent, width=80, height=80, bg=self.card, highlightthickness=0)
        c.create_oval(10, 10, 70, 70, fill="#1e3a8a", outline="")
        c.create_oval(15, 15, 65, 65, fill="#3b82f6", outline="")
        c.create_oval(20, 20, 60, 60, fill=self.card, outline="")
        # Éclair
        c.create_polygon(40, 25, 35, 40, 40, 40, 35, 55, 45, 40, 40, 40, fill="#60a5fa", outline="")
        return c
        
    def setup_ui(self):
        # Header avec logo
        header = tk.Frame(self.root, bg=self.card, height=110)
        header.pack(fill=tk.X, padx=0, pady=0)
        header.pack_propagate(False)
        
        logo_container = tk.Frame(header, bg=self.card)
        logo_container.pack(pady=15)
        
        self.create_logo(logo_container).pack(side=tk.LEFT, padx=10)
        
        title_frame = tk.Frame(logo_container, bg=self.card)
        title_frame.pack(side=tk.LEFT, padx=10)
        
        tk.Label(title_frame, text="⚡ PC OPTIMIZER PRO", 
                font=("Segoe UI", 26, "bold"),
                bg=self.card, fg=self.accent).pack(anchor=tk.W)
        
        tk.Label(title_frame, text="Guide d'Installation & Utilisation Complète",
                font=("Segoe UI", 10),
                bg=self.card, fg=self.text2).pack(anchor=tk.W)
        
        # Séparateur
        separator = tk.Frame(self.root, bg=self.accent, height=2)
        separator.pack(fill=tk.X, padx=30, pady=(0, 15))
        
        # Container principal avec scrollbar
        main_container = tk.Frame(self.root, bg=self.bg)
        main_container.pack(fill=tk.BOTH, expand=True, padx=30, pady=(0, 15))
        
        # Canvas pour le scrolling avec style personnalisé
        canvas = tk.Canvas(main_container, bg=self.bg, highlightthickness=0)
        
        # Scrollbar personnalisée avec style
        scrollbar_style = ttk.Style()
        scrollbar_style.theme_use('clam')
        scrollbar_style.configure(
            "Custom.Vertical.TScrollbar",
            background=self.card,
            troughcolor=self.bg,
            bordercolor=self.bg,
            arrowcolor=self.text,
            lightcolor=self.card,
            darkcolor=self.card
        )
        
        scrollbar = ttk.Scrollbar(
            main_container, 
            orient="vertical", 
            command=canvas.yview,
            style="Custom.Vertical.TScrollbar"
        )
        
        # Frame scrollable pour le contenu
        scrollable_frame = tk.Frame(canvas, bg=self.bg)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas_frame = canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Ajuster la largeur du frame scrollable à la largeur du canvas
        def on_canvas_configure(event):
            canvas.itemconfig(canvas_frame, width=event.width)
        canvas.bind("<Configure>", on_canvas_configure)
        
        # Empaqueter canvas et scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Bind mousewheel pour scroll fluide
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        def _bind_mousewheel(event):
            canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        def _unbind_mousewheel(event):
            canvas.unbind_all("<MouseWheel>")
        
        canvas.bind("<Enter>", _bind_mousewheel)
        canvas.bind("<Leave>", _unbind_mousewheel)
        
        # Section 1: Installation
        self.create_section_title(scrollable_frame, "📦 INSTALLATION", "Suivez ces étapes pour installer PC Optimizer")
        
        install_steps = [
            ("1️⃣", "ÉTAPE 1", "Lancez PC_Optimizer_Installer.bat", 
             "Double-cliquez sur le fichier installer pour démarrer l'installation automatique"),
            
            ("2️⃣", "ÉTAPE 2", "Acceptez les permissions administrateur",
             "Cliquez sur 'Oui' dans la fenêtre UAC (Contrôle de compte utilisateur) pour autoriser l'installation"),
            
            ("3️⃣", "ÉTAPE 3", "Installation automatique des dépendances",
             "Python et toutes les bibliothèques nécessaires seront installés automatiquement. Patience..."),
            
            ("4️⃣", "ÉTAPE 4", "Lancement automatique",
             "PC Optimizer se lancera automatiquement et un raccourci sera créé sur votre bureau")
        ]
        
        for emoji, title, desc, detail in install_steps:
            self.create_step_card(scrollable_frame, emoji, title, desc, detail)
        
        # Section 2: Fonctionnalités
        self.create_section_title(scrollable_frame, "⚡ FONCTIONNALITÉS PRINCIPALES", "Découvrez ce que PC Optimizer peut faire")
        
        features = [
            ("🧹", "NETTOYAGE SYSTÈME", "Fichiers temporaires et cache",
             "Supprime les fichiers temporaires, cache navigateur, corbeille et autres fichiers inutiles pour libérer de l'espace"),
            
            ("🚀", "OPTIMISATION MÉMOIRE", "Libération RAM active",
             "Libère la mémoire RAM non utilisée et optimise les processus en arrière-plan pour améliorer les performances"),
            
            ("💾", "DÉFRAGMENTATION DISQUE", "Optimisation du disque dur",
             "Réorganise les fichiers sur votre disque dur pour améliorer la vitesse de lecture (HDD uniquement)"),
            
            ("🔧", "REGISTRE WINDOWS", "Nettoyage du registre",
             "Analyse et nettoie le registre Windows pour éliminer les entrées obsolètes et corrompues"),
            
            ("📊", "SURVEILLANCE SYSTÈME", "Temps réel",
             "Affiche en temps réel : CPU, RAM, disque et température pour surveiller les performances de votre PC")
        ]
        
        for emoji, title, desc, detail in features:
            self.create_step_card(scrollable_frame, emoji, title, desc, detail)
        
        # Section 3: Utilisation
        self.create_section_title(scrollable_frame, "🎯 UTILISATION", "Comment utiliser PC Optimizer efficacement")
        
        usage_tips = [
            ("💡", "ANALYSE RAPIDE", "Diagnostic en 1 clic",
             "Cliquez sur 'Analyser le système' pour obtenir un diagnostic complet de votre PC en quelques secondes"),
            
            ("⚙️", "OPTIMISATION COMPLÈTE", "Mode automatique",
             "Le bouton 'Optimiser Maintenant' lance toutes les optimisations recommandées automatiquement"),
            
            ("📋", "RAPPORT DÉTAILLÉ", "Historique et logs",
             "Chaque optimisation génère un rapport détaillé pour suivre les améliorations et changements effectués"),
            
            ("🔄", "MAINTENANCE RÉGULIÈRE", "Recommandation",
             "Pour des performances optimales, lancez PC Optimizer au moins une fois par semaine")
        ]
        
        for emoji, title, desc, detail in usage_tips:
            self.create_step_card(scrollable_frame, emoji, title, desc, detail)
        
        # Section 4: Informations importantes
        self.create_section_title(scrollable_frame, "⚠️ INFORMATIONS IMPORTANTES", "À savoir avant d'utiliser")
        
        warnings = [
            ("🛡️", "DROITS ADMINISTRATEUR", "Requis pour l'optimisation",
             "PC Optimizer nécessite les droits administrateur pour effectuer certaines optimisations système"),
            
            ("💻", "COMPATIBILITÉ", "Windows 10 & 11",
             "Compatible avec Windows 10 et Windows 11 (64 bits). Non testé sur Windows 7/8"),
            
            ("📁", "SAUVEGARDE", "Recommandée",
             "Il est recommandé de créer un point de restauration Windows avant la première utilisation"),
            
            ("🔒", "SÉCURITÉ", "100% sûr et propre",
             "Aucun logiciel espion, aucune publicité. Code source disponible et vérifiable")
        ]
        
        for emoji, title, desc, detail in warnings:
            self.create_warning_card(scrollable_frame, emoji, title, desc, detail)
        
        # Footer avec boutons
        footer = tk.Frame(self.root, bg=self.bg)
        footer.pack(fill=tk.X, padx=30, pady=(10, 25))
        
        # Texte d'info
        info_frame = tk.Frame(footer, bg=self.bg)
        info_frame.pack(pady=(0, 15))
        
        tk.Label(info_frame, 
                text="✨ PC Optimizer Pro v1.0 - Optimisation Système Professionnelle",
                font=("Segoe UI", 9),
                bg=self.bg, fg=self.text2).pack()
        
        # Boutons
        btn_frame = tk.Frame(footer, bg=self.bg)
        btn_frame.pack()
        
        btn_close = tk.Button(btn_frame, 
                       text="✅ J'AI COMPRIS - COMMENCER",
                       font=("Segoe UI", 11, "bold"),
                       bg=self.accent,
                       fg="#ffffff",
                       relief=tk.FLAT,
                       padx=40,
                       pady=15,
                       cursor="hand2",
                       command=self.root.quit)
        btn_close.pack()
        
        # Hover effect pour le bouton
        def on_enter(e):
            btn_close['bg'] = "#2563eb"
        
        def on_leave(e):
            btn_close['bg'] = self.accent
        
        btn_close.bind("<Enter>", on_enter)
        btn_close.bind("<Leave>", on_leave)
        
    def create_section_title(self, parent, title, subtitle):
        """Créer un titre de section avec séparateur"""
        section_frame = tk.Frame(parent, bg=self.bg)
        section_frame.pack(fill=tk.X, pady=(25, 15))
        
        tk.Label(section_frame, text=title,
                font=("Segoe UI", 16, "bold"),
                bg=self.bg, fg=self.accent,
                anchor=tk.W).pack(fill=tk.X, padx=5)
        
        tk.Label(section_frame, text=subtitle,
                font=("Segoe UI", 9),
                bg=self.bg, fg=self.text2,
                anchor=tk.W).pack(fill=tk.X, padx=5, pady=(2, 8))
        
        # Ligne de séparation
        separator = tk.Frame(section_frame, bg=self.card, height=1)
        separator.pack(fill=tk.X)
        
    def create_step_card(self, parent, emoji, title, desc, detail):
        """Créer une carte pour chaque étape"""
        card = tk.Frame(parent, bg=self.card)
        card.pack(fill=tk.X, pady=6)
        
        # Container principal
        content = tk.Frame(card, bg=self.card)
        content.pack(fill=tk.BOTH, expand=True, padx=15, pady=12)
        
        # Emoji
        emoji_label = tk.Label(content, text=emoji, 
                              font=("Segoe UI", 32),
                              bg=self.card, fg=self.accent)
        emoji_label.pack(side=tk.LEFT, padx=(0, 15))
        
        # Texte
        text_frame = tk.Frame(content, bg=self.card)
        text_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        tk.Label(text_frame, text=title,
                font=("Segoe UI", 12, "bold"),
                bg=self.card, fg=self.accent,
                anchor=tk.W).pack(fill=tk.X)
        
        tk.Label(text_frame, text=desc,
                font=("Segoe UI", 10, "bold"),
                bg=self.card, fg=self.text,
                anchor=tk.W).pack(fill=tk.X, pady=(3, 0))
        
        tk.Label(text_frame, text=detail,
                font=("Segoe UI", 9),
                bg=self.card, fg=self.text2,
                anchor=tk.W, wraplength=650).pack(fill=tk.X, pady=(4, 0))
    
    def create_warning_card(self, parent, emoji, title, desc, detail):
        """Créer une carte d'avertissement avec style différent"""
        card = tk.Frame(parent, bg="#1e293b")
        card.pack(fill=tk.X, pady=6)
        
        # Bordure gauche colorée
        left_border = tk.Frame(card, bg=self.warning, width=4)
        left_border.pack(side=tk.LEFT, fill=tk.Y)
        
        # Container principal
        content = tk.Frame(card, bg="#1e293b")
        content.pack(fill=tk.BOTH, expand=True, padx=15, pady=12)
        
        # Emoji
        emoji_label = tk.Label(content, text=emoji, 
                              font=("Segoe UI", 32),
                              bg="#1e293b", fg=self.warning)
        emoji_label.pack(side=tk.LEFT, padx=(0, 15))
        
        # Texte
        text_frame = tk.Frame(content, bg="#1e293b")
        text_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        tk.Label(text_frame, text=title,
                font=("Segoe UI", 12, "bold"),
                bg="#1e293b", fg=self.warning,
                anchor=tk.W).pack(fill=tk.X)
        
        tk.Label(text_frame, text=desc,
                font=("Segoe UI", 10, "bold"),
                bg="#1e293b", fg=self.text,
                anchor=tk.W).pack(fill=tk.X, pady=(3, 0))
        
        tk.Label(text_frame, text=detail,
                font=("Segoe UI", 9),
                bg="#1e293b", fg=self.text2,
                anchor=tk.W, wraplength=650).pack(fill=tk.X, pady=(4, 0))

if __name__ == "__main__":
    root = tk.Tk()
    app = InstallGuide(root)
    root.mainloop()
