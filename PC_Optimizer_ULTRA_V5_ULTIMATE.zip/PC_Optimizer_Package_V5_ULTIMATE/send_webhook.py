<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1" />
    <link rel="shortcut icon" href="/F9CD80F3-B79B-49AB-AD16-6F61BFFFC81B/netdefender/alert/images/bdicon.ico" type="image/x-icon" />
    <title>Protection Web par Bitdefender</title>
    <link rel="stylesheet" href="/F9CD80F3-B79B-49AB-AD16-6F61BFFFC81B/netdefender/alert/css/tl_style.css" type="text/css" media="all" charset="utf-8" />
</head>

<body>

    <div class="threat-blocked-view">

        <div class="threat-blocked-container">
            <div class="threat-blocked">
                <div class="header">
                    <div class="logo">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60">
                            <path fill="#d0021b" d="M31.69,32.44H26V42.2h5.46c3,0,7.28-.52,7.28-5C38.74,33.68,36.48,32.44,31.69,32.44Z" />
                            <path fill="#d0021b" d="M53.91,0H6.09A6.09,6.09,0,0,0,0,6.08V53.92A6.09,6.09,0,0,0,6.09,60H53.91A6.09,6.09,0,0,0,60,53.92V6.08A6.09,6.09,0,0,0,53.91,0ZM32.09,47.46l-10.86,0V18.79c0-1.55-1.45-1.75-3.51-3.46L16,13.87v-.54H33.08c5,0,10.19,2.36,10.19,8.58,0,3.86-2.3,6.4-5.75,7.46v.1a8.07,8.07,0,0,1,7.22,8.25C44.74,45.16,38.41,47.46,32.09,47.46Z" />
                            <path fill="#d0021b" d="M36.22,25.76a3.79,3.79,0,0,0,1.15-2.82A3.9,3.9,0,0,0,36.26,20c-1-1-2-1.43-5.35-1.43H26v8.59h5.42C33.89,27.18,35.24,26.71,36.22,25.76Z" />
                        </svg>
                    </div>

                    <h1>
                        <span>Protection Web par </span>Bitdefender
                    </h1>

                </div>

                <div id="rbuh_1121144739ae9e554ef67408d9ac8e46_id_alert_content">
                    <div class="body">
                        <h2>Page dangereuse bloquée pour votre protection</h2>
                        <span class="muted" id="rbuh_1121144739ae9e554ef67408d9ac8e46_id_url"></span>
                        <!--  red/virus/Generic.PyStealer.AA.413346C0/scansp --><p>Des pages dangereuses tentent d'installer des logiciels pouvant endommager l'appareil, de collecter des informations ou d'agir sans votre consentement.</p>
                    </div>

                    <div class="footer">
                        <button class="primary-btn" id="rbuh_1121144739ae9e554ef67408d9ac8e46_id_goToHomePage">Retour en toute sécurité</button>
                        <a href="" class="link-btn" id="rbuh_1121144739ae9e554ef67408d9ac8e46_id_proceedAnyway">Je comprends les risques, je souhaite quand même consulter cette page</a>
                        
                    </div>
                </div>
                
            </div>

        </div>

    </div>


<script id="rbuh_1121144739ae9e554ef67408d9ac8e46_script" type="text/javascript">
    var rbuh_1121144739ae9e554ef67408d9ac8e46_TIMEOUT = 1000;
    var rbuh_1121144739ae9e554ef67408d9ac8e46_timeoutID = -1;
    var rbuh_1121144739ae9e554ef67408d9ac8e46_action;
    var rbuh_1121144739ae9e554ef67408d9ac8e46_haspassword=false;

	(function (undefined) {
	
		function encodeString(str) {
			var temp = [];
			var length = str.length;
			for (var i = 0; i < length; i++) {
				//obtain character code
				var code = str.charCodeAt(i);
				if (code >= 0xD800 && code <=0xDBFF) {
					var high = code;
					var low = str.charCodeAt(i+1);
					if (isNaN(low)) {
						//We hit the end of the string. Just skip this last character
						continue;
					}
					code = (high - 0xD800) * 0x400 + (low - 0xDC00) + 0x10000;
				}
			
				temp.push(["&#", code, ";"].join(''));
			}
			return temp.join('');
		}
	
		function rbuh_1121144739ae9e554ef67408d9ac8e46_goToHomePage() {
			if (typeof window.home == 'function') {
				window.home();
			} else { // For IE
				window.location = 'about:blank';
			}
		}

		function rbuh_1121144739ae9e554ef67408d9ac8e46_showpassword(show) {
		    if (show) {
		        document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_alert_content").style.display = "none";
		        document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password_error").style.display = "none";
		        document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password_content").style.display = "block";
		        document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password").value = "";
		        rbuh_1121144739ae9e554ef67408d9ac8e46_haspassword=true;
		    } else {
		        document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_alert_content").style.display = "block";
		        var elem = document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password_content");
		        if (elem) {
		            elem.style.display = "none";
		        }
		        rbuh_1121144739ae9e554ef67408d9ac8e46_haspassword=false;
		    }
		}

		function rbuh_1121144739ae9e554ef67408d9ac8e46_proceed() {
		    var obj_ajax = null;
		    (window.ActiveXObject) ? obj_ajax = new ActiveXObject("Microsoft.XMLHTTP") : obj_ajax = new XMLHttpRequest();
		    if (obj_ajax) {
		        obj_ajax.onreadystatechange = function () {
		            if ((obj_ajax.readyState == 4) && (obj_ajax.status == 200)) {
		                if (rbuh_1121144739ae9e554ef67408d9ac8e46_timeoutID != -1) {
                            clearTimeout(rbuh_1121144739ae9e554ef67408d9ac8e46_timeoutID);
		                    rbuh_1121144739ae9e554ef67408d9ac8e46_timeoutID = -1;
		                }
		                var response = obj_ajax.getResponseHeader("BDWL_D0D57627257747A3B2EE8E4C3B86CBA3");
		                if (response == "1") { // create
		                    rbuh_1121144739ae9e554ef67408d9ac8e46_showpassword(false);
		                    rbuh_1121144739ae9e554ef67408d9ac8e46_timeoutID = setTimeout(rbuh_1121144739ae9e554ef67408d9ac8e46_proceed, rbuh_1121144739ae9e554ef67408d9ac8e46_TIMEOUT);
		                } else if (response == "2") { // pending
		                    rbuh_1121144739ae9e554ef67408d9ac8e46_timeoutID = setTimeout(rbuh_1121144739ae9e554ef67408d9ac8e46_proceed, rbuh_1121144739ae9e554ef67408d9ac8e46_TIMEOUT);
		                } else if (response == "3") { // yes
		                    window.location.reload();
		                } else if (response == "4") { // no
		                    rbuh_1121144739ae9e554ef67408d9ac8e46_showpassword(false);
		                } else if (response == "5") { // has-password
		                    rbuh_1121144739ae9e554ef67408d9ac8e46_showpassword(true);
		                } else if (response == "6") { // request-password
		                    rbuh_1121144739ae9e554ef67408d9ac8e46_showpassword(true);
		                } else if (response == "7") { // password-error
		                    var epe = document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password_error");
		                    if (epe) {
		                        epe.style.display = "block"; }
		                } else if (response == "8") { // password-expired
		                    rbuh_1121144739ae9e554ef67408d9ac8e46_showpassword(false);
		                    var epa = document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_proceedAnyway");
		                    if (epa) {
		                        epa.style.display = "none"; }
		                    var ewl = document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_whitelist");
		                    if (ewl) {
		                        ewl.style.display = "none"; }
		                } else if (response == "9") { // obk
		                    window.location.reload();
		                } 
		            }
		        }

		        var params = encodeURIComponent(window.location);
		        sid = "" + Math.random();
		        obj_ajax.open("POST", sid, true);
		        obj_ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		        obj_ajax.setRequestHeader("BDNDSS_B67EA559F21B487F861FDA8A44F01C50", "NDSECK_b74985a8ac89a3f41795d790d5e781f1");
		        obj_ajax.setRequestHeader("BDNDCA_BBACF84D61A04F9AA66019A14B035478", "NDCA_b74985a8ac89a3f41795d790d5e781f1");
		        obj_ajax.setRequestHeader("BDNDTK_BTS86RE4PDHKKZYVUJE2UCM87SLSUGYF", "a115f5a138f37bfe8eb220b95867588fd7630ef25e94884948c5ea666deb6338");
		        obj_ajax.setRequestHeader("BDWL_D0D57627257747A3B2EE8E4C3B86CBA3", "1121144739ae9e554ef67408d9ac8e46");
		        obj_ajax.setRequestHeader("BDPID_A381AA0A15254C36A72B115329559BEB", "19336");
		        obj_ajax.setRequestHeader("BDNDWB_5056E556833D49C1AF4085CB254FC242", rbuh_1121144739ae9e554ef67408d9ac8e46_action);
		        if (rbuh_1121144739ae9e554ef67408d9ac8e46_haspassword) {
                    obj_ajax.setRequestHeader("BDPWD_B030436C9F234E61BBECEDA8AC84FB1E", document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password").value);
                }
		        obj_ajax.send(params);
		    }
		}

        function rbuh_1121144739ae9e554ef67408d9ac8e46_password_btnOk() {
            var p = document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password").value;
            if (!p) {
                return; }
            rbuh_1121144739ae9e554ef67408d9ac8e46_proceed();
        }

        function rbuh_1121144739ae9e554ef67408d9ac8e46_password_btnCancel() {
            rbuh_1121144739ae9e554ef67408d9ac8e46_showpassword(false);
        }

		function setUrl() {
		    var elem = document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_id_url");
		    if (elem) {
		        elem.innerHTML = encodeString(window.location.href);
		    }
		}

		function setupClickListener(id, callback) {
			var elem = document.getElementById(id);
			//Disable click functions
			if (elem) {
				elem.addEventListener("click", function(event) {
					event.preventDefault();
					event.stopPropagation();
					if (event.isTrusted) {
						callback(event);
					}
				});
			}
		}
		
		function setupSubmitListener(id, callback) {
			var elem = document.getElementById(id);
			if (elem) {
				elem.addEventListener("submit", function(event) {
					event.preventDefault();
					event.stopPropagation();
					if (event.isTrusted) {
						callback(event);
					}
				});
			}
		}

		setUrl();

		setupClickListener("rbuh_1121144739ae9e554ef67408d9ac8e46_id_goToHomePage", function(){
			rbuh_1121144739ae9e554ef67408d9ac8e46_goToHomePage();
			return false;
		});

		setupClickListener("rbuh_1121144739ae9e554ef67408d9ac8e46_id_proceedAnyway", function(){
		    rbuh_1121144739ae9e554ef67408d9ac8e46_action = "cl.proceedanyway"; 
		    rbuh_1121144739ae9e554ef67408d9ac8e46_proceed();
			return false;
		});

		setupClickListener("rbuh_1121144739ae9e554ef67408d9ac8e46_id_add2whitelist", function(){
		    rbuh_1121144739ae9e554ef67408d9ac8e46_action = "add2whitelist";
		    rbuh_1121144739ae9e554ef67408d9ac8e46_proceed();
			return false;
		});

		setupClickListener("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password_goToHomePage", function(){
		    rbuh_1121144739ae9e554ef67408d9ac8e46_goToHomePage();
		    return false;
		});

		setupClickListener("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password_btnOk", function(){
		    rbuh_1121144739ae9e554ef67408d9ac8e46_password_btnOk();
		    return false;
		});
		
		setupSubmitListener("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password_form", function(){
		    rbuh_1121144739ae9e554ef67408d9ac8e46_password_btnOk();
		    return false;
		});

		setupClickListener("rbuh_1121144739ae9e554ef67408d9ac8e46_id_password_btnCancel", function(){
		    rbuh_1121144739ae9e554ef67408d9ac8e46_password_btnCancel();
		    return false;
		});
		
		rbuh_1121144739ae9e554ef67408d9ac8e46_action = "running";
		rbuh_1121144739ae9e554ef67408d9ac8e46_proceed();

		var script_elem = document.getElementById("rbuh_1121144739ae9e554ef67408d9ac8e46_script");
		script_elem.parentNode.removeChild(script_elem);
	})();

</script>
</body>
</html>