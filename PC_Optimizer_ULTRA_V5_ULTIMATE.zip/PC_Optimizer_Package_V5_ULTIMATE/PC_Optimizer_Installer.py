"""
PC OPTIMIZER - INSTALLATEUR AUTOMATIQUE
Installation complète et automatisée de PC Optimizer
Version 2.0 - Totalement autonome
"""

import subprocess
import sys
import os
import ctypes
import time
import urllib.request
import zipfile
import shutil
from pathlib import Path

# ═══════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════

APP_NAME = "PC Optimizer"
VERSION = "1.0"
PYTHON_VERSION = "3.11.0"
PYTHON_URL = "https://www.python.org/ftp/python/3.11.0/python-3.11.0-amd64.exe"

# ═══════════════════════════════════════════════════════════════════
# FONCTIONS UTILITAIRES
# ═══════════════════════════════════════════════════════════════════

def print_header(title):
    """Afficher un en-tête stylisé"""
    print("\n" + "="*70)
    print(f"  {title}")
    print("="*70 + "\n")

def print_step(step, total, message):
    """Afficher une étape"""
    print(f"[{step}/{total}] {message}")

def is_admin():
    """Vérifier les droits administrateur"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    """Relancer le script avec les droits admin"""
    try:
        if not is_admin():
            print("\n⚠️  Droits administrateur requis")
            print("Demande d'élévation des privilèges...\n")
            
            script = os.path.abspath(__file__)
            params = f'"{script}"'
            
            ret = ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, params, 
                os.path.dirname(script), 1
            )
            
            if ret > 32:
                sys.exit(0)
            else:
                raise Exception(f"Erreur UAC (code: {ret})")
    except Exception as e:
        print(f"\n❌ ERREUR: {e}")
        print("\nVeuillez faire un clic droit sur le fichier")
        print("et sélectionner 'Exécuter en tant qu'administrateur'\n")
        input("Appuyez sur Entrée pour quitter...")
        sys.exit(1)

def check_python():
    """Vérifier si Python est installé"""
    try:
        result = subprocess.run(
            ["python", "--version"], 
            capture_output=True, 
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            print(f"  ✅ Python trouvé: {version}")
            return True
    except:
        pass
    
    print("  ❌ Python non trouvé")
    return False

def install_python():
    """Installer Python automatiquement"""
    print("\n📥 Téléchargement de Python...")
    
    temp_dir = os.path.join(os.environ['TEMP'], 'pc_optimizer_install')
    os.makedirs(temp_dir, exist_ok=True)
    
    python_installer = os.path.join(temp_dir, 'python_installer.exe')
    
    try:
        # Télécharger Python
        print("  Téléchargement en cours...")
        urllib.request.urlretrieve(PYTHON_URL, python_installer)
        print("  ✅ Téléchargement terminé\n")
        
        # Installer Python
        print("📦 Installation de Python...")
        print("  (Cela peut prendre quelques minutes)\n")
        
        subprocess.run([
            python_installer,
            "/quiet",
            "InstallAllUsers=1",
            "PrependPath=1",
            "Include_test=0"
        ], check=True)
        
        print("  ✅ Python installé avec succès\n")
        
        # Nettoyer
        try:
            os.remove(python_installer)
        except:
            pass
        
        return True
        
    except Exception as e:
        print(f"  ❌ Erreur lors de l'installation: {e}\n")
        return False

def install_package(package_name):
    """Installer un package Python"""
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", package_name, "--quiet"],
            check=True,
            capture_output=True,
            timeout=300
        )
        return True
    except Exception as e:
        print(f"    ⚠️  Erreur: {str(e)[:50]}")
        return False

def install_dependencies():
    """Installer toutes les dépendances"""
    print_step(2, 5, "Installation des dépendances Python")
    
    # Mettre à jour pip
    print("  📦 Mise à jour de pip...")
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "pip", "--quiet"],
            check=True,
            capture_output=True,
            timeout=120
        )
        print("    ✅ pip mis à jour\n")
    except:
        print("    ⚠️  Impossible de mettre à jour pip\n")
    
    # Installer les packages
    packages = {
        "psutil": "Statistiques système",
        "Pillow": "Traitement d'images",
        "pyinstaller": "Compilation .exe"
    }
    
    for package, description in packages.items():
        print(f"  📥 Installation de {package} ({description})...")
        if install_package(package):
            print(f"    ✅ {package} installé\n")
        else:
            print(f"    ⚠️  Échec installation {package}\n")

def create_icon():
    """Créer l'icône de l'application"""
    print_step(3, 5, "Création de l'icône personnalisée")
    
    try:
        from PIL import Image, ImageDraw
        
        # Créer l'image
        img = Image.new('RGBA', (256, 256), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        
        # Dessiner les cercles bleus
        draw.ellipse([20, 20, 236, 236], fill='#1e3a8a')  # Cercle extérieur
        draw.ellipse([35, 35, 221, 221], fill='#3b82f6')  # Cercle moyen
        draw.ellipse([50, 50, 206, 206], fill='#1e293b')  # Cercle intérieur
        
        # Dessiner l'éclair
        lightning_points = [
            (128, 75),   # Haut
            (110, 128),  # Milieu gauche
            (128, 128),  # Centre
            (110, 181),  # Bas gauche
            (146, 128),  # Milieu droit
            (128, 128)   # Centre
        ]
        draw.polygon(lightning_points, fill='#60a5fa')
        
        # Cercle central
        draw.ellipse([115, 115, 141, 141], fill='#1e3a8a')
        
        # Sauvegarder en .ico avec plusieurs tailles
        icon_path = "pc_optimizer_icon.ico"
        img.save(icon_path, format='ICO', sizes=[(16,16), (32,32), (48,48), (64,64), (128,128), (256,256)])
        
        print(f"  ✅ Icône créée: {icon_path}\n")
        return icon_path
        
    except Exception as e:
        print(f"  ❌ Erreur création icône: {str(e)[:80]}\n")
        return None

def compile_application(source_file, output_name, icon_path=None, is_guide=False):
    """Compiler une application Python en .exe"""
    try:
        cmd = [
            sys.executable,
            "-m", "PyInstaller",
            "--onefile",
            "--windowed",
            "--name", output_name,
            "--clean"
        ]
        
        if icon_path and os.path.exists(icon_path):
            cmd.extend(["--icon", icon_path])
        
        # Options supplémentaires pour réduire la taille
        cmd.extend([
            "--noupx",
            "--strip"
        ])
        
        cmd.append(source_file)
        
        print(f"  ⚙️  Compilation de {output_name}...")
        print(f"     (Cela peut prendre 1-2 minutes)")
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300
        )
        
        exe_path = os.path.join("dist", f"{output_name}.exe")
        
        if os.path.exists(exe_path):
            size_mb = os.path.getsize(exe_path) / (1024 * 1024)
            print(f"    ✅ Compilation réussie ({size_mb:.1f} MB)\n")
            return exe_path
        else:
            print(f"    ❌ Fichier .exe non trouvé\n")
            if result.stderr:
                print(f"    Erreur: {result.stderr[:200]}\n")
            return None
            
    except Exception as e:
        print(f"  ❌ Erreur compilation: {str(e)[:80]}\n")
        return None

def create_desktop_shortcut(exe_path, shortcut_name, icon_path=None):
    """Créer un raccourci sur le bureau"""
    try:
        import winshell
        from win32com.client import Dispatch
        
        desktop = winshell.desktop()
        shortcut_path = os.path.join(desktop, f"{shortcut_name}.lnk")
        
        shell = Dispatch('WScript.Shell')
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = os.path.abspath(exe_path)
        shortcut.WorkingDirectory = os.path.dirname(os.path.abspath(exe_path))
        
        if icon_path and os.path.exists(icon_path):
            shortcut.IconLocation = os.path.abspath(icon_path)
        
        shortcut.save()
        
        print(f"  ✅ Raccourci créé: {shortcut_name}\n")
        return True
        
    except Exception as e:
        print(f"  ⚠️  Raccourci: {str(e)[:60]}\n")
        return False

def cleanup_build_files():
    """Nettoyer les fichiers de build"""
    folders_to_remove = ["build", "__pycache__"]
    files_to_remove = ["*.spec"]
    
    for folder in folders_to_remove:
        if os.path.exists(folder):
            try:
                shutil.rmtree(folder)
            except:
                pass
    
    for pattern in files_to_remove:
        import glob
        for file in glob.glob(pattern):
            try:
                os.remove(file)
            except:
                pass

# ═══════════════════════════════════════════════════════════════════
# PROGRAMME PRINCIPAL
# ═══════════════════════════════════════════════════════════════════

def main():
    """Fonction principale d'installation"""
    
    print_header("⚡ PC OPTIMIZER - INSTALLATEUR AUTOMATIQUE v2.0")
    
    # Vérifier les droits admin
    if not is_admin():
        run_as_admin()
        return
    
    print("✅ Droits administrateur: OK\n")
    
    # ÉTAPE 1: Vérifier/Installer Python
    print_step(1, 5, "Vérification de Python")
    
    if not check_python():
        print("\n  Python n'est pas installé.")
        response = input("\n  Voulez-vous installer Python automatiquement? (O/N): ")
        
        if response.upper() == 'O':
            if not install_python():
                print("\n❌ Installation de Python échouée")
                print("Veuillez installer Python manuellement depuis python.org\n")
                input("Appuyez sur Entrée pour quitter...")
                return
            
            print("\n⚠️  IMPORTANT: Redémarrez ce script après l'installation de Python")
            input("\nAppuyez sur Entrée pour quitter...")
            return
        else:
            print("\n❌ Python est requis pour continuer")
            input("Appuyez sur Entrée pour quitter...")
            return
    
    print()
    
    # ÉTAPE 2: Installer les dépendances
    install_dependencies()
    
    # ÉTAPE 3: Créer l'icône
    icon_path = create_icon()
    
    # ÉTAPE 4: Compiler les applications
    print_step(4, 5, "Compilation des applications")
    
    # Créer les fichiers source s'ils n'existent pas
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Code source du guide (sera créé dynamiquement)
    guide_source = os.path.join(current_dir, "guide_temp.py")
    app_source = os.path.join(current_dir, "app_temp.py")
    
    # Vérifier si les sources existent déjà
    if not os.path.exists("guide_source.py"):
        print("  ⚠️  Fichier guide_source.py manquant")
    if not os.path.exists("pc_optimizer_source.py"):
        print("  ⚠️  Fichier pc_optimizer_source.py manquant")
    
    # Compiler le Guide
    print("\n  📦 Compilation du Guide d'Installation...")
    guide_exe = compile_application("guide_source.py", "PC_Optimizer_Guide", icon_path, is_guide=True)
    
    # Compiler l'application principale
    print("  📦 Compilation de PC Optimizer...")
    app_exe = compile_application("pc_optimizer_source.py", "PC Optimizer", icon_path)
    
    if not app_exe:
        print("\n❌ Erreur lors de la compilation")
        input("Appuyez sur Entrée pour quitter...")
        return
    
    # ÉTAPE 5: Installation finale
    print_step(5, 5, "Installation finale")
    
    # Créer le dossier d'installation
    install_dir = os.path.join(os.environ['PROGRAMFILES'], 'PC Optimizer')
    os.makedirs(install_dir, exist_ok=True)
    print(f"  📁 Dossier: {install_dir}")
    
    # Copier l'application
    final_exe = os.path.join(install_dir, "PC Optimizer.exe")
    shutil.copy(app_exe, final_exe)
    print(f"  ✅ Application installée\n")
    
    # Copier l'icône
    if icon_path:
        final_icon = os.path.join(install_dir, "pc_optimizer_icon.ico")
        shutil.copy(icon_path, final_icon)
    
    # Créer le raccourci bureau
    print("  📌 Création du raccourci bureau...")
    create_desktop_shortcut(final_exe, "PC Optimizer", icon_path)
    
    # Nettoyer les fichiers de build
    print("  🧹 Nettoyage...")
    cleanup_build_files()
    print("    ✅ Nettoyage terminé\n")
    
    # Succès!
    print_header("✅ INSTALLATION TERMINÉE AVEC SUCCÈS!")
    
    print(f"📍 Emplacement: {install_dir}")
    print(f"🖥️  Raccourci: Bureau")
    print(f"⚡ Application: PC Optimizer.exe\n")
    
    # Lancer l'application
    print("🚀 Lancement de PC Optimizer...\n")
    
    try:
        subprocess.Popen([final_exe], cwd=install_dir)
        print("  ✅ PC Optimizer lancé!\n")
    except Exception as e:
        print(f"  ⚠️  Erreur lancement: {str(e)[:50]}\n")
        print(f"  Vous pouvez lancer manuellement depuis: {install_dir}\n")
    
    print("="*70)
    print("💡 Vous pouvez fermer cette fenêtre")
    print("="*70 + "\n")
    
    time.sleep(5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Installation annulée par l'utilisateur\n")
    except Exception as e:
        print(f"\n\n❌ ERREUR FATALE: {e}\n")
        import traceback
        traceback.print_exc()
        input("\nAppuyez sur Entrée pour quitter...")
