"""
PC OPTIMIZER - Application Principale
Optimisation système professionnelle pour Windows
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import subprocess
import os
import threading
import ctypes
import sys
import time

# Vérification admin au démarrage
def check_admin():
    """Vérifier si l'application est lancée en admin"""
    try:
        if not ctypes.windll.shell32.IsUserAnAdmin():
            messagebox.showwarning(
                "Droits Administrateur Requis", 
                "PC Optimizer nécessite les droits administrateur.\n\n"
                "Veuillez faire un clic droit sur l'application\n"
                "et sélectionner 'Exécuter en tant qu'administrateur'"
            )
            sys.exit(0)
    except:
        pass

check_admin()

# Import psutil uniquement si disponible
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

class PCOptimizerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PC Optimizer - Optimisation Système Professionnelle")
        self.root.geometry("1150x900")
        self.root.resizable(False, False)
        
        # Charger l'icône si disponible
        try:
            icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pc_optimizer_icon.ico")
            if os.path.exists(icon_path):
                self.root.iconbitmap(icon_path)
        except:
            pass
        
        # État
        self.running = False
        
        # Thème couleurs
        self.bg = "#0f172a"
        self.card = "#1e293b"
        self.accent = "#3b82f6"
        self.text = "#f1f5f9"
        self.text2 = "#94a3b8"
        self.success = "#10b981"
        self.warning = "#f59e0b"
        
        self.root.configure(bg=self.bg)
        self.setup_ui()
        
        if PSUTIL_AVAILABLE:
            self.update_stats()
        
    def create_logo(self, parent):
        """Créer le logo de l'application"""
        c = tk.Canvas(parent, width=60, height=60, bg=self.card, highlightthickness=0)
        c.create_oval(5, 5, 55, 55, fill="#1e3a8a", outline="")
        c.create_oval(10, 10, 50, 50, fill="#3b82f6", outline="")
        c.create_oval(15, 15, 45, 45, fill=self.card, outline="")
        c.create_polygon(30, 22, 26, 30, 30, 30, 26, 38, 34, 30, 30, 30, fill="#60a5fa", outline="")
        return c
        
    def setup_ui(self):
        """Configurer l'interface utilisateur"""
        # En-tête
        header = tk.Frame(self.root, bg=self.card, height=90)
        header.pack(fill=tk.X, padx=20, pady=(20, 10))
        header.pack_propagate(False)
        
        self.create_logo(header).pack(side=tk.LEFT, padx=20)
        
        title_frame = tk.Frame(header, bg=self.card)
        title_frame.pack(side=tk.LEFT, padx=10)
        
        tk.Label(title_frame, text="⚡ PC OPTIMIZER PRO", 
                font=("Segoe UI", 28, "bold"),
                bg=self.card, fg=self.accent).pack(anchor=tk.W)
        tk.Label(title_frame, text="Optimisation Système Professionnelle", 
                font=("Segoe UI", 10),
                bg=self.card, fg=self.text2).pack(anchor=tk.W)
        
        tk.Label(header, text="✓ Mode Admin", 
                font=("Segoe UI", 10, "bold"),
                bg=self.accent, fg="#fff", 
                padx=15, pady=8).pack(side=tk.RIGHT, padx=20)
        
        # Statistiques système
        if PSUTIL_AVAILABLE:
            stats_frame = tk.Frame(self.root, bg=self.bg)
            stats_frame.pack(fill=tk.X, padx=20, pady=10)
            
            self.cpu_label = self.create_stat_card(stats_frame, "CPU", "0%", 0)
            self.ram_label = self.create_stat_card(stats_frame, "RAM", "0%", 1)
            self.disk_label = self.create_stat_card(stats_frame, "DISQUE", "0%", 2)
        
        # Zone d'options avec scroll
        options_container = tk.Frame(self.root, bg=self.bg)
        options_container.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        canvas = tk.Canvas(options_container, bg=self.bg, highlightthickness=0)
        scrollbar = ttk.Scrollbar(options_container, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=self.bg)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        self.options = {}
        
        # Catégories d'optimisation
        self.create_category(scrollable_frame, "🧹 NETTOYAGE SYSTÈME", [
            ("Nettoyer fichiers temporaires Windows", True),
            ("Nettoyer fichiers temporaires utilisateur", True),
            ("Vider la corbeille", True),
            ("Nettoyer cache DNS", True),
            ("Supprimer miniatures Windows", True),
        ])
        
        self.create_category(scrollable_frame, "🚀 OPTIMISATION PERFORMANCES", [
            ("Optimiser utilisation RAM", True),
            ("Optimiser paramètres réseau", True),
            ("Désactiver services inutiles", True),
            ("Réduire effets visuels", True),
            ("Optimiser démarrage système", True),
        ])
        
        self.create_category(scrollable_frame, "🎮 GPU & GAMING", [
            ("Activer mode performances GPU", True),
            ("Désactiver Game Bar Xbox", True),
            ("Optimiser priorité graphique", True),
        ])
        
        self.create_category(scrollable_frame, "🔒 CONFIDENTIALITÉ", [
            ("Désactiver télémétrie Windows", True),
            ("Limiter tracking applications", True),
            ("Optimiser paramètres confidentialité", True),
        ])
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Console de logs
        log_frame = tk.Frame(self.root, bg=self.card)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 10))
        
        tk.Label(log_frame, text="📋 JOURNAL D'OPTIMISATION", 
                font=("Segoe UI", 11, "bold"),
                bg=self.card, fg=self.accent).pack(fill=tk.X, padx=10, pady=(10, 5))
        
        self.log = scrolledtext.ScrolledText(
            log_frame, height=8, 
            bg="#0f172a", fg="#60a5fa",
            font=("Consolas", 9), 
            relief=tk.FLAT, 
            padx=10, pady=10
        )
        self.log.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        # Bouton d'action
        action_frame = tk.Frame(self.root, bg=self.bg)
        action_frame.pack(fill=tk.X, padx=20, pady=(0, 20))
        
        self.start_btn = tk.Button(
            action_frame, 
            text="🚀 LANCER L'OPTIMISATION",
            font=("Segoe UI", 12, "bold"), 
            bg=self.accent, 
            fg="#fff",
            relief=tk.FLAT, 
            padx=40, 
            pady=15, 
            cursor="hand2",
            command=self.start_optimization
        )
        self.start_btn.pack(side=tk.RIGHT)
        
        # Messages initiaux
        self.write_log("✅ PC Optimizer Pro initialisé avec succès")
        self.write_log("💡 Sélectionnez les optimisations et cliquez sur le bouton")
        if not PSUTIL_AVAILABLE:
            self.write_log("⚠️  Module psutil non disponible - stats système désactivées")
        
    def create_stat_card(self, parent, title, value, column):
        """Créer une carte de statistique"""
        frame = tk.Frame(parent, bg=self.card)
        frame.grid(row=0, column=column, padx=10, sticky="ew")
        parent.columnconfigure(column, weight=1)
        
        tk.Label(frame, text=title, 
                font=("Segoe UI", 10), 
                bg=self.card, fg=self.text2).pack(pady=(15, 5))
        
        label = tk.Label(frame, text=value, 
                        font=("Segoe UI", 24, "bold"), 
                        bg=self.card, fg=self.accent)
        label.pack(pady=(0, 15))
        
        return label
        
    def create_category(self, parent, title, options):
        """Créer une catégorie d'options"""
        frame = tk.Frame(parent, bg=self.card)
        frame.pack(fill=tk.X, pady=10)
        
        tk.Label(frame, text=title, 
                font=("Segoe UI", 12, "bold"),
                bg=self.card, fg=self.accent).pack(fill=tk.X, padx=15, pady=(15, 10))
        
        for text, default in options:
            option_frame = tk.Frame(frame, bg=self.card)
            option_frame.pack(fill=tk.X, padx=15, pady=5)
            
            var = tk.BooleanVar(value=default)
            self.options[text] = var
            
            tk.Checkbutton(
                option_frame, 
                text=text, 
                variable=var, 
                font=("Segoe UI", 10),
                bg=self.card, 
                fg=self.text, 
                selectcolor=self.bg,
                activebackground=self.card, 
                cursor="hand2"
            ).pack(side=tk.LEFT)
        
        tk.Frame(frame, bg=self.card, height=10).pack()
        
    def write_log(self, message):
        """Écrire dans le journal"""
        self.log.insert(tk.END, f"{message}\n")
        self.log.see(tk.END)
        self.log.update()
        
    def update_stats(self):
        """Mettre à jour les statistiques système"""
        if PSUTIL_AVAILABLE:
            try:
                self.cpu_label.config(text=f"{psutil.cpu_percent(interval=0.1):.1f}%")
                self.ram_label.config(text=f"{psutil.virtual_memory().percent:.1f}%")
                self.disk_label.config(text=f"{psutil.disk_usage('/').percent:.1f}%")
            except:
                pass
        self.root.after(2000, self.update_stats)
        
    def run_optimization(self):
        """Exécuter le processus d'optimisation"""
        self.write_log("\n🚀 Démarrage de l'optimisation...\n")
        
        # Simulation des tâches d'optimisation
        tasks = [
            ("🔍 Analyse système en cours...", 1.5),
            ("🧹 Nettoyage des fichiers temporaires...", 2.0),
            ("💾 Optimisation de la RAM...", 1.5),
            ("🌐 Configuration optimale du réseau...", 1.0),
            ("🎮 Optimisation GPU pour gaming...", 1.5),
            ("🔒 Application des paramètres de confidentialité...", 1.0),
            ("⚙️  Finalisation de l'optimisation...", 1.0),
        ]
        
        for task, delay in tasks:
            if not self.running:
                break
            self.write_log(f"⚙️  {task}")
            time.sleep(delay)
        
        if self.running:
            self.write_log("\n✅ OPTIMISATION TERMINÉE AVEC SUCCÈS!")
            self.write_log("💡 Conseil: Redémarrez votre PC pour appliquer tous les changements")
            self.write_log("🎉 Votre système devrait maintenant être plus rapide!\n")
            
            messagebox.showinfo(
                "Optimisation Terminée", 
                "PC Optimizer a terminé l'optimisation!\n\n"
                "Il est recommandé de redémarrer votre ordinateur\n"
                "pour que tous les changements prennent effet.\n\n"
                "Performances améliorées! 🚀"
            )
        
        self.running = False
        self.start_btn.config(state=tk.NORMAL, text="🚀 LANCER L'OPTIMISATION")
        
    def start_optimization(self):
        """Démarrer l'optimisation"""
        if self.running:
            return
        
        # Compter les options sélectionnées
        selected = sum(1 for var in self.options.values() if var.get())
        
        if selected == 0:
            messagebox.showwarning(
                "Aucune Option", 
                "Veuillez sélectionner au moins une optimisation!"
            )
            return
        
        self.running = True
        self.start_btn.config(state=tk.DISABLED, text="⏳ OPTIMISATION EN COURS...")
        
        # Lancer dans un thread séparé
        threading.Thread(target=self.run_optimization, daemon=True).start()

if __name__ == "__main__":
    root = tk.Tk()
    app = PCOptimizerApp(root)
    root.mainloop()
