═══════════════════════════════════════════════════════════════
    ⚡ NEXUS OPTI v2.0 - OPTIMISEUR PC PERFORMANCE
═══════════════════════════════════════════════════════════════

🎯 DESCRIPTION
Nexus Opti est votre outil d'optimisation PC tout-en-un pour
maximiser les performances de votre ordinateur, booster vos FPS
en jeu et accélérer Windows.

═══════════════════════════════════════════════════════════════
✨ FONCTIONNALITÉS
═══════════════════════════════════════════════════════════════

🧹 NETTOYAGE SYSTÈME (7 options)
   ✓ Nettoyage fichiers temporaires
   ✓ Vidage de la corbeille
   ✓ Nettoyage cache Windows Update
   ✓ Vidage cache DNS
   ✓ Nettoyage dossier Téléchargements (>30 jours)
   ✓ Suppression miniatures Windows
   ✓ Nettoyage journaux d'événements

🚀 OPTIMISATION PERFORMANCES (7 options)
   ✓ Optimisation de la RAM
   ✓ Priorités système optimisées
   ✓ Optimisation réseau TCP/IP
   ✓ Désactivation services inutiles
   ✓ Réduction effets visuels
   ✓ Optimisation fichier de pagination
   ✓ Optimisation démarrage Windows

💾 OPTIMISATION DISQUE (3 options)
   ✓ Défragmentation HDD
   ✓ Optimisation SSD (TRIM)
   ✓ Nettoyage points de restauration

🎮 OPTIMISATION GPU & GAMING (5 options)
   ✓ Mode Performances maximales
   ✓ Désactivation Xbox Game Bar
   ✓ Optimisation paramètres graphiques
   ✓ Désactivation DVR Xbox
   ✓ Optimisation priorité GPU

═══════════════════════════════════════════════════════════════
🚀 INSTALLATION
═══════════════════════════════════════════════════════════════

1. Exécutez "INSTALLER.bat" en tant qu'administrateur
   → Installe Python et les dépendances automatiquement

2. Lancez "NEXUS_OPTI_v2.pyw"
   → Le programme se relance automatiquement en mode admin
   → Acceptez la demande UAC

3. Sélectionnez vos options et cliquez sur "LANCER L'OPTIMISATION"

═══════════════════════════════════════════════════════════════
💡 RÉSULTATS ATTENDUS
═══════════════════════════════════════════════════════════════

Après une optimisation complète :

🎮 GAMING
   ✓ +20-40% FPS dans les jeux
   ✓ Réduction micro-stutters
   ✓ Latence réseau réduite

💻 SYSTÈME
   ✓ Démarrage 30-50% plus rapide
   ✓ RAM libérée jusqu'à 30%
   ✓ Plusieurs GB d'espace récupérés

═══════════════════════════════════════════════════════════════
⚙️ CONFIGURATION REQUISE
═══════════════════════════════════════════════════════════════

✓ Windows 10/11 (64-bit)
✓ 2 GB RAM minimum
✓ 100 MB espace disque libre
✓ Droits administrateur (auto-géré)

═══════════════════════════════════════════════════════════════
📞 SUPPORT
═══════════════════════════════════════════════════════════════

Discord:    Supersonic_12
TikTok:     @cesarioh12_76
Site web:   https://nexus-apps.com

═══════════════════════════════════════════════════════════════
© 2026 Nexus Apps - 100% Gratuit, Sans publicité
═══════════════════════════════════════════════════════════════
