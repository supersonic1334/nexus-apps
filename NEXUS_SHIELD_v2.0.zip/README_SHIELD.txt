═══════════════════════════════════════════════════════════════
    🛡️ NEXUS SHIELD v2.0 - PROTECTION & SÉCURITÉ PC
═══════════════════════════════════════════════════════════════

🎯 DESCRIPTION
Nexus Shield est votre centre de sécurité complet pour protéger
votre PC contre les virus, malwares, et pour réparer les fichiers
système corrompus. Protection maximale en quelques clics.

═══════════════════════════════════════════════════════════════
✨ FONCTIONNALITÉS
═══════════════════════════════════════════════════════════════

🦠 SCANS ANTIVIRUS WINDOWS DEFENDER (4 options)
   ✓ Scan RAPIDE (2-5 min)
   ✓ Scan COMPLET (15-30 min)
   ✓ Scan PERSONNALISÉ C:\ (10-20 min)
   ✓ Mise à jour définitions antivirus

🔍 SCANS FICHIERS SYSTÈME (3 options)
   ✓ Scan SFC - Fichiers système corrompus (10-15 min)
   ✓ Scan DISM - Réparation image système (15-30 min)
   ✓ Analyse erreurs disque CHKDSK

🔒 PROTECTION & PARE-FEU (4 options)
   ✓ Vérification état du pare-feu
   ✓ Activation protection temps réel
   ✓ Vérification protection malwares
   ✓ Activation protection cloud

👁️ CONFIDENTIALITÉ & ANTI-TRACKING (4 options)
   ✓ Blocage télémétrie Windows
   ✓ Désactivation publicité personnalisée
   ✓ Nettoyage historique navigation
   ✓ Suppression cookies

🌐 SÉCURITÉ RÉSEAU (4 options)
   ✓ Analyse connexions réseau
   ✓ Vidage cache DNS sécurisé
   ✓ Reset pile TCP/IP
   ✓ Analyse ports ouverts

═══════════════════════════════════════════════════════════════
🚀 INSTALLATION
═══════════════════════════════════════════════════════════════

1. Exécutez "INSTALLER.bat" en tant qu'administrateur
   → Installe Python et les dépendances automatiquement

2. Lancez "NEXUS_SHIELD_v2.pyw"
   → Le programme se relance automatiquement en mode admin
   → Acceptez la demande UAC

3. Sélectionnez vos scans et cliquez sur "LANCER LES SCANS"

⚠️ IMPORTANT: Les scans de sécurité nécessitent les droits
   administrateur pour fonctionner correctement.

═══════════════════════════════════════════════════════════════
⏱️ DURÉE DES SCANS
═══════════════════════════════════════════════════════════════

SCANS RAPIDES (< 5 min)
   ✓ Mise à jour antivirus
   ✓ Scan antivirus rapide
   ✓ Vérifications pare-feu et protection

SCANS MOYENS (5-15 min)
   ✓ Scan SFC (fichiers système)
   ✓ Scan personnalisé C:\

SCANS LONGS (15-30 min)
   ✓ Scan antivirus complet
   ✓ DISM (réparation image système)

💡 CONSEIL: Lancez les scans longs le soir ou pendant une pause

═══════════════════════════════════════════════════════════════
🛡️ PROTECTION ASSURÉE
═══════════════════════════════════════════════════════════════

Après les scans Nexus Shield :

✓ PC protégé contre virus et malwares
✓ Fichiers système réparés
✓ Pare-feu et protections activées
✓ Confidentialité renforcée
✓ Réseau sécurisé

═══════════════════════════════════════════════════════════════
⚙️ CONFIGURATION REQUISE
═══════════════════════════════════════════════════════════════

✓ Windows 10/11 (64-bit)
✓ Windows Defender activé
✓ 2 GB RAM minimum
✓ 100 MB espace disque libre
✓ Droits administrateur (OBLIGATOIRE)

═══════════════════════════════════════════════════════════════
⚠️ NOTES IMPORTANTES
═══════════════════════════════════════════════════════════════

• Les scans antivirus utilisent Windows Defender (intégré)
• Fermez tous les programmes avant les scans longs
• Ne forcez pas la fermeture pendant un scan
• Les menaces détectées sont automatiquement traitées
• Certaines réparations nécessitent un redémarrage

═══════════════════════════════════════════════════════════════
📞 SUPPORT
═══════════════════════════════════════════════════════════════

Discord:    Supersonic_12
TikTok:     @cesarioh12_76
Site web:   https://nexus-apps.com

═══════════════════════════════════════════════════════════════
© 2026 Nexus Apps - 100% Gratuit, Sans publicité
═══════════════════════════════════════════════════════════════
